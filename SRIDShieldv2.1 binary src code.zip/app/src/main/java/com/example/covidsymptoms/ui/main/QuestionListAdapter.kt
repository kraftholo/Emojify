package com.example.covidsymptoms.ui.main

import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.recyclerview.widget.*
import com.example.covidsymptoms.R
import com.example.covidsymptoms.models.Question
import com.example.covidsymptoms.util.Constants.Companion.CHECKBOX_TYPE
import com.example.covidsymptoms.util.Constants.Companion.COLOR_GREEN
import com.example.covidsymptoms.util.Constants.Companion.COLOR_ORANGE
import com.example.covidsymptoms.util.Constants.Companion.COLOR_RED
import com.example.covidsymptoms.util.Constants.Companion.EDITBOX_TYPE
import com.example.covidsymptoms.util.Constants.Companion.GROUP_TYPE
import com.example.covidsymptoms.util.Constants.Companion.HEADER_TYPE
import com.example.covidsymptoms.util.Constants.Companion.OTHER_TYPE
import com.example.covidsymptoms.util.Constants.Companion.SPINNER_TYPE
import kotlinx.android.synthetic.main.layout_checkbox_list_item.view.*
import kotlinx.android.synthetic.main.layout_checkbox_list_item.view.item_checkBox
import kotlinx.android.synthetic.main.layout_editbox_list_item.view.*
import kotlinx.android.synthetic.main.layout_group_list_item.view.*
import kotlinx.android.synthetic.main.layout_othertype_list_item.view.*
import kotlinx.android.synthetic.main.layout_spinner_list_item.view.*
import kotlinx.android.synthetic.main.layout_view_type_104.view.*


class QuestionListAdapter(private val interaction: Interaction? = null) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Question>() {

        override fun areItemsTheSame(oldItem: Question, newItem: Question): Boolean {
            return oldItem.questionStr.equals(newItem.questionStr,true)
        }

        override fun areContentsTheSame(oldItem: Question, newItem: Question): Boolean {
            return oldItem == newItem
        }

    }
   private val differ =
        AsyncListDiffer(
            QuestionRecyclerChangeCallback(this),
            AsyncDifferConfig.Builder(DIFF_CALLBACK).build()
        )

    internal inner class QuestionRecyclerChangeCallback(
        private val adapter: QuestionListAdapter
    ) : ListUpdateCallback {

        override fun onChanged(position: Int, count: Int, payload: Any?) {
            adapter.notifyItemRangeChanged(position, count, payload)
        }

        override fun onInserted(position: Int, count: Int) {
            adapter.notifyItemRangeChanged(position, count)
        }

        override fun onMoved(fromPosition: Int, toPosition: Int) {
            adapter.notifyDataSetChanged()
        }

        override fun onRemoved(position: Int, count: Int) {
            adapter.notifyDataSetChanged()
        }
    }

    override fun getItemViewType(position: Int): Int {

        if(position == 0) return HEADER_TYPE

        // for Difference in checkBoxTypeHOlder and  OtherViewTypeHOlder
        if(differ.currentList[position-1].viewType == 101){
            //hard coding here
            if(differ.currentList[position-1].hasChildren){
                return OTHER_TYPE
            }
        }
        Log.d("QuestionListAdapter","getItemViewType() - ${differ.currentList[position-1].viewType} returned")
        return differ.currentList[position-1].viewType
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        when(viewType){

            HEADER_TYPE -> {
                return HeaderTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_recycler_view_header,
                        parent,
                        false
                    ),
                    interaction
                )

            }

            //101
            CHECKBOX_TYPE -> {
                return CheckBoxTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_checkbox_list_item,
                        parent,
                        false
                    ),
                    interaction
                )
            }

            //102
            EDITBOX_TYPE -> {
                return EditBoxTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_editbox_list_item,
                        parent,
                        false
                    ),
                    interaction
                )
            }

            //103
            SPINNER_TYPE ->{
                return SpinnerTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_spinner_list_item,
                        parent,
                        false
                    ),
                    interaction
                )
            }

            //104
            GROUP_TYPE ->{
                return GroupTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_view_type_104,
                        parent,
                        false
                    ),
                    interaction
                )
            }

            //105
            OTHER_TYPE ->{
                return OtherTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_othertype_list_item,
                        parent,
                        false
                    ),
                    interaction
                )
            }

            //not going to happen
            else ->{
                return CheckBoxTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_checkbox_list_item,
                        parent,
                        false
                    ),
                    interaction
                )
            }

        }

    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is CheckBoxTypeHolder -> {
                holder.bind(differ.currentList[position-1])
            }
            is EditBoxTypeHolder -> {
                holder.bind(differ.currentList[position-1])
            }

            is SpinnerTypeHolder -> {
                holder.bind(differ.currentList[position-1])
            }

            is GroupTypeHolder -> {
                holder.bind(differ.currentList[position-1])
            }

            is OtherTypeHolder -> {
                holder.bind(differ.currentList[position-1])
            }

            is HeaderTypeHolder ->{
                //Nothing to bind
            }
        }
    }

    override fun getItemCount(): Int {
        return differ.currentList.size + 1              //+1 since header is extra at top
    }

    fun submitList(list: List<Question>) {
        differ.submitList(list)
    }

    class HeaderTypeHolder
    constructor(
        itemView: View,
        private val interaction: Interaction?
    ) : RecyclerView.ViewHolder(itemView) {

    }

    class CheckBoxTypeHolder                                                        //answer used is boolean
    constructor(
        itemView: View,
        private val interaction: Interaction?
    ) : RecyclerView.ViewHolder(itemView) {

        fun bind(ques: Question) = with(itemView) {
            itemView.setOnClickListener {
                interaction?.onItemSelected(adapterPosition, ques)
            }
            item_checkBoxTV.text = ques.questionStr

            //coming from server
            if(ques.answer.equals("true",true)){
                item_checkBox.isChecked = true
            }
            else if(ques.answer.equals("false",true)){
                item_checkBox.isChecked = false
            }
            else{
                item_checkBox.isChecked = false
                ques.answer = "false"                   //if empty comes from server, preset the answer to send as false
            }

            //updating the question if user clicks checkbox of a PARENT
            item_checkBox.setOnClickListener{
                Log.d("QuestionListAdapter","CheckBoxTypeHolder onClick of  Question called")
                ques.answer = item_checkBox.isChecked.toString()
            }
        }

    }


    class EditBoxTypeHolder                                                                 //answer used is String
    constructor(
        itemView: View,
        private val interaction: Interaction?
    ) : RecyclerView.ViewHolder(itemView) {

        fun bind(ques: Question) = with(itemView) {
            itemView.setOnClickListener {
                interaction?.onItemSelected(adapterPosition, ques)
            }
            item_editBoxTV.setText(ques.questionStr)
            item_editTextBox.setText(ques.answer)

            //updating the list

            item_editBoxTV.setOnFocusChangeListener( object : View.OnFocusChangeListener{
                override fun onFocusChange(v: View?, hasFocus: Boolean) {
                    if(!hasFocus) {
                        val answerToSend = (v as EditText).text.toString().replace("'","\\'")
                        ques.answer  = answerToSend
                        Log.d("QuestionListAdapter","EditBoxTypeHolder saving furtherQuesEditBoxAns ${ques.answer}  ")
                    }
                }

            })
        }
    }

    class SpinnerTypeHolder                                                   //answer used is Int 0/1/2
    constructor(
        itemView: View,
        private val interaction: Interaction?
    ) : RecyclerView.ViewHolder(itemView) {

        fun bind(ques: Question) = with(itemView) {
            itemView.setOnClickListener {
                interaction?.onItemSelected(adapterPosition, ques)
            }

            Log.d("QuestionListAdapter","SpinnerTypeHolder - spinnerStr list - ${ques.spinnerStr}")
            val mAdapter = MySpinnerAdapter(context,R.layout.layout_spinner_option_row,ques.spinnerStr)
            item_spinner.adapter = mAdapter

            item_spinnerTV.setText(ques.questionStr)
            if(ques.answer == ""){
                ques.answer = "0"
            }
            item_spinner.setSelection(ques.answer.toInt())

            //updating question according to option chosen
            item_spinner?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
                override fun onNothingSelected(parent: AdapterView<*>?) {
                }

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    Log.d("QuestionListAdapter","SpinnerTypeHolder saving selected value  - $position")
                    ques.answer = position.toString()
                }

            }


        }
    }


    class OtherTypeHolder
    constructor(
        itemView: View,
        private val interaction: Interaction?
    ) : RecyclerView.ViewHolder(itemView) {

        fun bind(ques: Question) = with(itemView) {
            itemView.setOnClickListener {
                interaction?.onItemSelected(adapterPosition, ques)
            }

            item_otherQuesTitleTV.setText(ques.questionStr)
            item_furtherQuesTV.setText(ques.children[0].questionStr)

            //coming from server
            if(ques.answer.equals("true",true)){
                item_otherQuesTitleCheckBox.isChecked = true
                item_furtherQuesEditBox.isEnabled = true
                item_furtherQuesTV.isEnabled = true
                item_furtherQuesEditBox.setText( ques.children[0].answer)
            }
            else if(ques.answer.equals("false",true)){
                item_otherQuesTitleCheckBox.isChecked = false
            }
            else{
                item_otherQuesTitleCheckBox.isChecked = false
                ques.answer = "false"                   //if empty comes from server, preset the answer to send as false
            }


            item_otherQuesTitleCheckBox.setOnClickListener {v ->
                Log.d("QuestionListAdapter","OtherTypeHolder checkBox was clicked ")
                if((v as CheckBox).isChecked){
                    Log.d("QuestionListAdapter","OtherTypeHolder enabling furtherQues ")
                    ques.answer = "true"
                    item_furtherQuesEditBox.isEnabled = true
                    item_furtherQuesTV.isEnabled = true
                }else{
                    Log.d("QuestionListAdapter","OtherTypeHolder disabling furtherQues ")
                    item_furtherQuesEditBox.setText("")
                    ques.answer = "false"
                    ques.children[0].answer = ""
                    item_furtherQuesEditBox.isEnabled = false
                    item_furtherQuesTV.isEnabled = false
                }
            }

            //updating answer
            item_furtherQuesEditBox.setOnFocusChangeListener( object : View.OnFocusChangeListener{
                override fun onFocusChange(v: View?, hasFocus: Boolean) {
                    if(!hasFocus) {
                        val answerToSend = (v as EditText).text.toString().replace("'","\\'")
                        ques.answer  = answerToSend
                        ques.children[0].answer  = answerToSend
                        Log.d("QuestionListAdapter","OtherTypeHolder saving furtherQuesEditBoxAns - ${ ques.children[0].answer } ")
                    }
                }

            })

        }
    }

    class GroupTypeHolder
    constructor(
        itemView: View,
        private val interaction: Interaction?
    ) : RecyclerView.ViewHolder(itemView) {

        fun bind(ques: Question) = with(itemView) {
            itemView.setOnClickListener {
                interaction?.onItemSelected(adapterPosition, ques)
            }

            val subQuestionList = ques.children
            group_question_title.setText(ques.questionStr)

            item_checkBoxTV_1.setText(subQuestionList[0].questionStr)
            item_checkBox_1.setOnClickListener{
                Log.d("QuestionListAdapter","GroupTypeHolder onClick of subQues 1 called")
                subQuestionList[0].answer = when(item_checkBox_1.isChecked){
                        true -> "true"
                        false -> "false"
                }

                item_checkBox_5.isChecked = false           //ui change
                subQuestionList[4].answer = "false"      //data change
            }

            item_checkBoxTV_2.setText(subQuestionList[1].questionStr)
            item_checkBox_2.setOnClickListener{
                Log.d("QuestionListAdapter","GroupTypeHolder onClick of subQues 2 called")
                subQuestionList[1].answer = when(item_checkBox_2.isChecked){
                    true -> "true"
                    false -> "false"
                }

                item_checkBox_5.isChecked = false           //ui change
                subQuestionList[4].answer = "false"      //data change
            }

            item_checkBoxTV_3.setText(subQuestionList[2].questionStr)
            item_checkBox_3.setOnClickListener{
                Log.d("QuestionListAdapter","GroupTypeHolder onClick of subQues 3 called")
                subQuestionList[2].answer =  when(item_checkBox_3.isChecked){
                    true -> "true"
                    false -> "false"
                }

                item_checkBox_5.isChecked = false           //ui change
                subQuestionList[4].answer = "false"      //data change
            }

            item_checkBoxTV_4.setText(subQuestionList[3].questionStr)
            item_checkBox_4.setOnClickListener{
                Log.d("QuestionListAdapter","GroupTypeHolder onClick of subQues 4 called")
                subQuestionList[3].answer =  when(item_checkBox_4.isChecked){
                    true -> "true"
                    false -> "false"
                }

                item_checkBox_5.isChecked = false            //ui change
                subQuestionList[4].answer = "false"      //data change
            }

            item_checkBoxTV_5.setText(subQuestionList[4].questionStr)
            item_checkBox_5.setOnClickListener{
                Log.d("QuestionListAdapter","GroupTypeHolder onClick of subQues 5 called")
                subQuestionList[4].answer =  when(item_checkBox_5.isChecked){
                    true -> "true"
                    false -> "false"
                }

                //ui change
                item_checkBox_1.isChecked = false
                item_checkBox_2.isChecked = false
                item_checkBox_3.isChecked = false
                item_checkBox_4.isChecked = false

                //data change
                subQuestionList[0].answer = "false"
                subQuestionList[1].answer = "false"
                subQuestionList[2].answer = "false"
                subQuestionList[3].answer = "false"
            }

        }

    }

    fun getSymptomsCheckedStatus():Boolean{
        var noSymptomSelected = true
        Log.d("QuestionAdapter","getSymptomsCheckedStatus - $noSymptomSelected")
        for( parentQuestion:Question in differ.currentList ){
            if(parentQuestion.viewType == GROUP_TYPE){
                val childQuestions = parentQuestion.children
                if(childQuestions.size>1){
                    for( childQuestion in childQuestions){
                        if(childQuestion.answer.equals("true",true)){
                            if(!noSymptomSelected) break
                            noSymptomSelected = false
                        }
                    }
                }
            }
        }
        return noSymptomSelected
    }

    private fun updateStatus(currStatus : String , quesImpact : String ) : String{
        var retVal = ""
        if(currStatus.equals(COLOR_RED,true)){
            retVal = currStatus
        }

        if(currStatus.equals(COLOR_ORANGE,true)){
            if(quesImpact.equals(COLOR_RED,true)){
                retVal = quesImpact
            }else{
                retVal = currStatus
            }
        }

        if(currStatus.equals(COLOR_GREEN,true)) {
            if(quesImpact.equals("none",true)){
                retVal = currStatus
            }else{
                retVal = quesImpact
            }
        }

        return retVal
    }

    //will return a color other than green,orange,red iff =>  Inside loop and currentHealthStatus = green , some question's impactOnStatus = "example"
    // then, this function will return "example"/ "" as color

    fun calculateHealthStatus(): String{
        var currentHealthStatus = COLOR_GREEN
        for( parentQuestion:Question in differ.currentList ){
            if(currentHealthStatus.equals(COLOR_RED,true)) break

            //currentHealthStatus is orange/green
            when(parentQuestion.viewType){
                CHECKBOX_TYPE ->{
                    if(parentQuestion.answer.equals("true",true)) {
                        Log.d(
                            "QuestionAdapter",
                            "Health Status updated to  -${parentQuestion.impactOnStatus} from $currentHealthStatus"
                        )
                        currentHealthStatus = updateStatus(currentHealthStatus, parentQuestion.impactOnStatus)
                    }
                }

                GROUP_TYPE -> {
                    val childQuestions = parentQuestion.children

                    if(childQuestions[childQuestions.size-1].answer.equals("true",true) ){
                        //if none of the above is checked ::Assumption -> it is the last item in childQuestions list
                        Log.d("QuestionAdapter","None of the above was  checked")
                    }else{
                        for( childQuestion in childQuestions){
                            if(childQuestion.answer.equals("true",true) ){
                                //do not check futher if red also, i need to check if atleast one of the child here is enabled
                                Log.d("QuestionAdapter","Health Status updated to  -${childQuestion.impactOnStatus}from $currentHealthStatus")
                                currentHealthStatus = updateStatus(currentHealthStatus,childQuestion.impactOnStatus)
                                if(currentHealthStatus.equals(COLOR_RED,true)) break
                            }
                        }
                    }
                }

                OTHER_TYPE -> {
                    if(parentQuestion.answer.equals("true",true) ) {
                        Log.d(
                            "QuestionAdapter",
                            "Health Status updated to  -${parentQuestion.impactOnStatus} from $currentHealthStatus"
                        )
                        currentHealthStatus = updateStatus(currentHealthStatus, parentQuestion.impactOnStatus)
                    }
                }
                else -> {
                    //no contribution in score
                }
            }
        }
        return currentHealthStatus.toLowerCase().trim()                         //possible return values - "red","green","orange"
    }


    interface Interaction {
        fun onItemSelected(position: Int, item: Question)
    }
}

