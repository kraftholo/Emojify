package com.example.covidsymptoms.ui.auth

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import com.example.covidsymptoms.R
import com.example.covidsymptoms.models.Organisation
import com.example.covidsymptoms.ui.auth.adapter.OrganizationSpinnerAdapter
import com.example.covidsymptoms.ui.auth.state.AuthStateEvent
import com.example.covidsymptoms.ui.auth.state.SignInFields
import com.example.covidsymptoms.ui.displayErrorDialog
import kotlinx.android.synthetic.main.fragment_signin.*

//Now this fragment is not used!!
class SignInFragment : Fragment() {

    val TAG = "SignInFragment"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        /*    Returns a property delegate to access parent activity's ViewModel, if factoryProducer is specified
            then ViewModelProvider.Factory returned by it will be used to create ViewModel first time.Otherwise,
            the activity's androidx.activity.ComponentActivity.getDefaultViewModelProviderFactory will be used*/

        val viewModel: AuthViewModel by activityViewModels()
        Log.d(TAG,"Viewmodel - ${viewModel.hashCode()}")
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_signin, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //fire off sign in network request
        initSpinner()
        signInButton.setOnClickListener {
            signIn()
        }
        forgotPasswordTV.setOnClickListener{
            findNavController().navigate(R.id.action_signInFragment_to_forgotPasswordFragment)
        }
    }

    private fun initSpinner(){
        val viewModel: AuthViewModel by activityViewModels()
        val orgListInViewModel = viewModel.getCurrentViewStateOrNew().orgListReceived
        val spinnerList = ArrayList<String>()

        for( org : Organisation in orgListInViewModel!!){
            spinnerList.add(org.orgName)
        }
        Log.e("RegisterFragment","spinnerlist is $spinnerList")
        activity?.let {
            val mAdapter = OrganizationSpinnerAdapter(it,R.layout.layout_org_spinner_option_row,spinnerList)
            orgSpinner.adapter = mAdapter
            orgSpinner.setSelection(0)
        }
    }

    private fun signIn(){
        val vm: AuthViewModel by activityViewModels()

        val signInFieldErrors = SignInFields(
            input_empID.text.toString(),
            input_password.text.toString()
        ).isValidForSignIn()

        if(signInFieldErrors != SignInFields.SignInError.none()){
            context!!.displayErrorDialog(signInFieldErrors)
        }else{
            vm.setStateEvent(AuthStateEvent.SignInAttemptEvent(
                input_empID.text.toString(),
                input_password.text.toString(),
                orgSpinner.selectedItem as String
            ))
        }
    }
}
