package com.example.covidsymptoms.ui.auth

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.covidsymptoms.models.AuthToken
import com.example.covidsymptoms.models.EmpDetail
import com.example.covidsymptoms.models.Organisation
import com.example.covidsymptoms.repository.AuthRepository
import com.example.covidsymptoms.ui.BaseViewModel
import com.example.covidsymptoms.ui.DataState
import com.example.covidsymptoms.ui.auth.state.AuthStateEvent
import com.example.covidsymptoms.ui.auth.state.AuthStateEvent.*
import com.example.covidsymptoms.ui.auth.state.AuthViewState
import com.example.covidsymptoms.ui.auth.state.RegistrationFields
import com.example.covidsymptoms.ui.auth.state.SignInFields
import com.example.covidsymptoms.util.AbsentLiveData

class AuthViewModel : BaseViewModel<AuthStateEvent, AuthViewState>() {

    private val _retryButtonVisibility = MutableLiveData<Boolean>()
    private val _visibleTV = MutableLiveData<String>()

    val retryButtonVisibility : LiveData<Boolean>
        get() = _retryButtonVisibility

    val visibleTV : LiveData<String>
        get() = _visibleTV

    override fun handleStateEvent(stateEvent: AuthStateEvent): LiveData<DataState<AuthViewState>> {
        when (stateEvent) {

            is SignInAttemptEvent -> {
                return AuthRepository.attemptSignIn(
                    stateEvent.employeeID,
                    stateEvent.password,
                    stateEvent.orgName
                )
            }

            is RegisterAttemptEvent -> {
                return AuthRepository.attemptRegistration(
                    stateEvent.employeeID,
                    stateEvent.orgName,
                    stateEvent.password
                )
            }

            is GetLatestAppVersion -> {
                return AuthRepository.getLatestAppVersion(
                    stateEvent.userAgent,
                    stateEvent.isAppFirstRequest
                )
            }

            is GetOrganisationListEvent -> {
                return AuthRepository.getOrganisationListFromServer()
            }

            is None -> return AbsentLiveData.create()
        }
    }

    override fun initNewViewState(): AuthViewState {
        return AuthViewState()
    }

    fun setRetryButtonVisibility(bool: Boolean){
        _retryButtonVisibility.value = bool
    }

    fun setVisibleTextView(string: String){
        _visibleTV.value = string
    }

    fun setOrganisationList(orgList: List<Organisation>){
        val update = getCurrentViewStateOrNew()
        if(update.orgListReceived == orgList) return

        update.orgListReceived = orgList
        _viewState.value = update
    }


    fun setLatestAppVersion(version: String){
        val update = getCurrentViewStateOrNew()
        if(update.latestVersion == version) return

        update.latestVersion = version
        _viewState.value = update
    }

    fun setAuthToken(authToken: AuthToken){
        val update = getCurrentViewStateOrNew()
        if(update.authToken == authToken){
            return
        }
        update.authToken = authToken
        _viewState.value = update
    }
    fun setHealthStatus(healthStatus: String){
        val update = getCurrentViewStateOrNew()
        if(update.healthStatus == healthStatus){
            return
        }
        update.healthStatus = healthStatus
        _viewState.value = update
    }

    fun setLastFilledTime(lastFilledTime: String){
        val update = getCurrentViewStateOrNew()
        if(update.time == lastFilledTime){
            return
        }
        update.time = lastFilledTime
        _viewState.value = update
    }

    fun setEmpDetails(empDetails: EmpDetail){
        val update = getCurrentViewStateOrNew()
        if(update.empDetail == empDetails){
            return
        }
        update.empDetail = empDetails
        _viewState.value = update
    }

    fun cancelActiveJobs() {
        AuthRepository.cancelActiveJobs()
    }

}