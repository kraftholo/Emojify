package com.example.covidsymptoms.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.os.SystemClock
import android.util.Log
import androidx.core.app.AlarmManagerCompat
import com.example.covidsymptoms.receiver.AlarmReceiver
import com.example.covidsymptoms.receiver.NextAlarmReceiver
import com.example.covidsymptoms.util.Constants.Companion.KEY_ALARM_SET
import com.example.covidsymptoms.util.Constants.Companion.PREFS_NAME
import java.util.*


private val TAG = "AlarmUtils"

/*Cases for alarm placement
 * 1) App's 1st launch      ->  In AuthActivity call to initializeAlarm() and setNextAlarm()    [ALARM_FOR_TOMORROW_7_CODE + ALARM_FOR_PLUS_1_HR_CODE]
 * 2) Subsequent launches   ->  No alarm set ( checked from sharedPref)
 * 3) 7 am Notification     ->  Next day's 7 am alarm set + (if notification is shown)          [ALARM_FOR_TOMORROW_7_CODE + ALARM_FOR_PLUS_1_HR_CODE]
 * 4) Reboot                ->  Today's 7 am alarm is set + Next Day's 7 am alarm is set        [ALARM_FOR_TODAY_7_CODE + ALARM_FOR_TOMORROW_7_CODE]
 *
 *  Apart from this, EVERY notification popup schedules and alarm for next hour ALARM_FOR_PLUS_1_HR_CODE
 * */

 val ALARM_FOR_TOMORROW_7_CODE = 0
 val ALARM_FOR_PLUS_1_HR_CODE = 1
 val ALARM_FOR_TODAY_7_CODE = 2

//called on appStart if sharedPrefs has false is KEY_ALARM_SET
fun AlarmManager.initializeAlarm(context: Context){         //everyDay at 8am from tommorow onwards
    val firingCal = Calendar.getInstance()
    firingCal.add(Calendar.DATE,1)

    firingCal.set(Calendar.HOUR_OF_DAY, 7)
    firingCal.set(Calendar.MINUTE, 0)
    firingCal.set(Calendar.SECOND, 0)

    val sharedPreferences = context.getSharedPreferences(PREFS_NAME,MODE_PRIVATE)
    val editor = sharedPreferences.edit()
    editor.putBoolean(KEY_ALARM_SET,true)
    editor.apply()

    val intendedTime = firingCal.timeInMillis
    Log.e(TAG, "initializeAlarm() firing time - ${firingCal.timeInMillis} or ${firingCal.time}")

    val intent = Intent(context, AlarmReceiver::class.java)
    val pendingIntent = PendingIntent.getBroadcast(
        context, ALARM_FOR_TOMORROW_7_CODE, intent, PendingIntent.FLAG_UPDATE_CURRENT
    )

    AlarmManagerCompat.setExactAndAllowWhileIdle(                                           //set for next day exact 7
        this,
        AlarmManager.RTC_WAKEUP,
        intendedTime,
        pendingIntent
    )
}

//called after reboot completed to set alarm for everyday + today ( so it fires instantly)
fun AlarmManager.initializeAlarmAfterReboot(context: Context){
    Log.e(TAG,"initializeAlarmAfterReboot()")
    val firingCal = Calendar.getInstance()
    firingCal.set(Calendar.HOUR_OF_DAY, 7)
    firingCal.set(Calendar.MINUTE, 0)
    firingCal.set(Calendar.SECOND, 0)

    val sharedPreferences = context.getSharedPreferences(PREFS_NAME,MODE_PRIVATE)
    val editor = sharedPreferences.edit()
    editor.putBoolean(KEY_ALARM_SET,true)
    editor.commit()

    val intendedTime = firingCal.timeInMillis
    Log.e(TAG, "initializeAlarmAfterReboot() firing time - ${firingCal.timeInMillis} or ${firingCal.time}")

    val intent = Intent(context, AlarmReceiver::class.java)
    val pendingIntent = PendingIntent.getBroadcast(
        context, ALARM_FOR_TODAY_7_CODE, intent, PendingIntent.FLAG_UPDATE_CURRENT            //this flag needs to be different! else when initializeAlarm is called after this,it is overridden!
    )

    AlarmManagerCompat.setExactAndAllowWhileIdle(                                                       //set today's exact alarm
        this,
        AlarmManager.RTC_WAKEUP,
        intendedTime,
        pendingIntent
    )
}

//called after showing the notification for filling out the questionnaire
fun AlarmManager.setNextAlarm(context: Context){
    val intent = Intent(context, NextAlarmReceiver::class.java)
    val oneHour = AlarmManager.INTERVAL_HOUR
    val pendingIntent = PendingIntent.getBroadcast(
        context, ALARM_FOR_PLUS_1_HR_CODE, intent, PendingIntent.FLAG_UPDATE_CURRENT
    )
    Log.e(TAG,"setNextAlarm() for ${SystemClock.elapsedRealtime()+oneHour}")
    AlarmManagerCompat.setExactAndAllowWhileIdle(this,AlarmManager.ELAPSED_REALTIME_WAKEUP,
        SystemClock.elapsedRealtime()+oneHour,
        pendingIntent
        )
}

//called on update of questionnaire on server
fun AlarmManager.cancelNextAlarm(context: Context){
    Log.e(TAG,"cancelNextAlarm()")
    val intent = Intent(context, AlarmReceiver::class.java)
    val pendingIntent = PendingIntent.getBroadcast(
        context, ALARM_FOR_PLUS_1_HR_CODE, intent, PendingIntent.FLAG_UPDATE_CURRENT
    )
    cancel(pendingIntent)
}