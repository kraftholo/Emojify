package com.example.covidsymptoms.ui.auth

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.example.covidsymptoms.R
import com.example.covidsymptoms.models.Organisation
import com.example.covidsymptoms.ui.auth.adapter.OrganizationSpinnerAdapter
import com.example.covidsymptoms.ui.auth.state.AuthStateEvent
import com.example.covidsymptoms.ui.auth.state.RegistrationFields
import com.example.covidsymptoms.ui.displayErrorDialog

import kotlinx.android.synthetic.main.fragment_register.*

class RegisterFragment : Fragment() {

    val TAG = "RegisterFragment"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        /*    Returns a property delegate to access parent activity's ViewModel, if factoryProducer is specified
            then ViewModelProvider.Factory returned by it will be used to create ViewModel first time.Otherwise,
            the activity's androidx.activity.ComponentActivity.getDefaultViewModelProviderFactory will be used*/

        val viewModel: AuthViewModel by activityViewModels()
        Log.d(TAG,"Viewmodel - ${viewModel.hashCode()}")

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initSpinner()
        register_button.setOnClickListener {
            register()
        }

    }

    //TODO: change this later
    private fun initSpinner(){
        val viewModel: AuthViewModel by activityViewModels()
        val orgListInViewModel = viewModel.getCurrentViewStateOrNew().orgListReceived
        val spinnerList = ArrayList<String>()
        for( org : Organisation in orgListInViewModel!!){
            spinnerList.add(org.orgName)
        }
        Log.e("RegisterFragment","spinnerlist is $spinnerList")

        activity?.let {
            val mAdapter = OrganizationSpinnerAdapter(it,R.layout.layout_org_spinner_option_row,spinnerList)
            orgSpinner.adapter = mAdapter
            orgSpinner.setSelection(0)
        }
    }

    private fun register(){
        val vm : AuthViewModel by activityViewModels()

        //This check can be refactored to be performed in AuthRepository
        val registrationFieldErrors = RegistrationFields(
            empID.text.toString(),
            passwordET.text.toString(),
            confirmPasswordET.text.toString()
        ).isValidForRegistration()

        if(registrationFieldErrors != RegistrationFields.RegistrationError.none()){
            context!!.displayErrorDialog(registrationFieldErrors)                           //Kotlin ViewExtensions used
        }
        else{
            vm.setStateEvent(AuthStateEvent.RegisterAttemptEvent(
                empID.text.toString(),
                orgSpinner.selectedItem as String,
                passwordET.text.toString()
            ))
        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_register, container, false)
    }

}
