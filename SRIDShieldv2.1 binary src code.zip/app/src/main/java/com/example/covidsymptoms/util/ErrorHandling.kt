package com.example.covidsymptoms.util

class ErrorHandling {

    companion object{

        const val NETWORK_TIMEOUT_OCCURED = "Network request timed out! Please try again after sometime."
        const val NETWORK_TIMEOUT_OCCURED_FIRST_REQUEST = "Network request timed out!"
        const val ERROR_CHECK_NETWORK_CONNECTION = "Check network connection."
        const val UNABLE_TODO_OPERATION_WO_INTERNET = "This application requires internet connection. Please check your internet connectivity"

        const val UNABLE_TODO_OPERATION_WO_INTERNET_FIRST_REQUEST  = "Can't do that operation without an internet connection special case for first request"

        const val ERROR_UNKNOWN = "Unknown error"

        const val AUTHTOKEN_EXPIRED = "Token Expired"

        //generic string for internal server error code =107
        const val INTERNAL_SERVER_ERROR_MESSAGE = "Server is not responding. Please try again after sometime."

        //getLatestApiVersion
        const val GET_LATEST_API_VERSION_FAIL = "GetLatestApiVersion_Response Failed"                   //on this i show server not responding

        //getOrganisationList
        const val GET_ORG_LIST_FAIL = "GetOrganisationList_Response Failed"                             //on this i put SRID default in orglist

        //Filling a (EmployeeID) not convertible to INT
        const val CONVERSION_ERROR_SIGN_IN = "Sign In Failed, invalid employee id"
        const val CONVERSION_ERROR_REG = "Registration Failed, invalid employee id"

        //getQuestionnaire endpoint
        const val QUESTIONNAIRE_NOT_AVAILABLE = "Questionnaire Response OK, questionnaire not available"
        const val QUESTIONNAIRE_INTERNAL_SERVER_ERROR = "Questionnaire Response fail, Internal server error"

        //announcement endpoint
        const val ANNOUNCEMENT_INTERNAL_SERVER_ERROR = "Announcement Response fail, Internal server error"



        fun isNetworkError(msg: String): Boolean{
            when{
                msg.contains(NETWORK_TIMEOUT_OCCURED) -> return true
                else-> return false
            }
        }
    }
}