package com.example.covidsymptoms.ui.main

import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.afollestad.materialdialogs.MaterialDialog
import com.example.covidsymptoms.R
import com.example.covidsymptoms.models.Question
import com.example.covidsymptoms.repository.AuthRepository
import com.example.covidsymptoms.session.SessionManager
import com.example.covidsymptoms.ui.main.state.MainStateEvent
import com.example.covidsymptoms.util.Constants
import com.example.covidsymptoms.util.DateUtils
import com.example.covidsymptoms.util.TopSpacingItemDecoration
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_update_symptoms.*

class UpdateSymptomsFragment : Fragment(),QuestionListAdapter.Interaction {

    override fun onItemSelected(position: Int, item: Question) {
        //do nothing right now
    }

    val TAG = "UpdateSymptomsFragment"

    private lateinit var recyclerAdapter : QuestionListAdapter
    var healthStatus_calculated = "NotYet"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        /*    Returns a property delegate to access parent activity's ViewModel, if factoryProducer is specified
            then ViewModelProvider.Factory returned by it will be used to create ViewModel first time.Otherwise,
            the activity's androidx.activity.ComponentActivity.getDefaultViewModelProviderFactory will be used*/

        val viewModel: MainViewModel by activityViewModels()

        Log.d(TAG,"Viewmodel - ${viewModel.hashCode()}")
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        update_button.setOnClickListener {
            updateChangesToServer()
        }
        val vm: MainViewModel by activityViewModels()
        initRecyclerView()
        subscribeObservers()
    }

    private fun updateChangesToServer(){
        update_button.isFocusable = true
        update_button.isFocusableInTouchMode = true
        update_button.requestFocus()
        update_button.isFocusable = false
        update_button.isFocusableInTouchMode = false

        otherWork()
    }

    private fun otherWork(){
        val vm : MainViewModel by activityViewModels()

        val noSymptomChecked  = recyclerAdapter.getSymptomsCheckedStatus()
        Log.e("UpdateSymptomsFragment","noSymptomChecked = $noSymptomChecked")

        if(noSymptomChecked){
            MaterialDialog(context!!).show {
                title(R.string.text_error)
                message ( R.string.no_symptom_selected )
                positiveButton(R.string.text_ok)
                cancelable(false)
                cancelOnTouchOutside(false)
            }
        }else{
            val healthStatus = recyclerAdapter.calculateHealthStatus()                  //runs the test
            Log.e("UpdateSymptomsFragment"," healthStatus = $healthStatus")
            healthStatus_calculated = healthStatus
            MaterialDialog(context!!).show {
                title(R.string.employee_undertaking_title)
                message(R.string.employee_undertaking_message)
                positiveButton(R.string.text_ok){
                    //Toast.makeText(context,"The status to be sent is - $healthStatus",Toast.LENGTH_SHORT).show()
                    vm.setTime(DateUtils.getTime())
                    vm.setStateEvent(MainStateEvent.UpdateEvent(vm.currEmpDetail!!.orgName,vm.lastFilledTime!!,healthStatus,vm.getCurrentViewStateOrNew().updationFields?.questionList!!))
                }
                cancelable(false)
                cancelOnTouchOutside(false)
                negativeButton (R.string.text_cancel)
            }
        }
    }

    private fun initRecyclerView(){
        questionRV.apply {
            layoutManager = LinearLayoutManager(this@UpdateSymptomsFragment.context)

            recyclerAdapter = QuestionListAdapter(this@UpdateSymptomsFragment)
            val topSpacingItemDecorator = TopSpacingItemDecoration(30)
            removeItemDecoration(topSpacingItemDecorator)
            addItemDecoration(topSpacingItemDecorator)
            adapter = recyclerAdapter
        }
    }

    private fun subscribeObservers(){
        val vm : MainViewModel by activityViewModels()

        vm.dataState.observe(viewLifecycleOwner, Observer {dataState ->
            dataState?.let {dataState ->
                dataState.data?.let {
                    it.response?.let {event ->
                        event.peekContent()?.let {response ->
                            if(response.message.equals(Constants.UPDATION_101,true)){
                                vm.setStatus(healthStatus_calculated)
                            }
                        }
                    }
                }
            }
        })

        //changes after i change from mainactivity
        vm.viewState.observe(viewLifecycleOwner, Observer {viewState ->
            viewState?.let {
                it.updationFields?.let {
                    Log.d("UpdateSymptomsFragment","submit list - ${it.questionList}")
                    recyclerAdapter.submitList(it.questionList!!)
                }

            }
        })
    }

    override fun onDestroyView() {
        questionRV.adapter = null
        super.onDestroyView()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_update_symptoms, container, false)
    }

}
