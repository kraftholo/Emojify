package com.example.covidsymptoms.models

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Organisation(
    @SerializedName("name")
    @Expose
    var orgName : String

) : Parcelable{
    override fun toString(): String {
        return "Organisation(orgName='$orgName')"
    }
}