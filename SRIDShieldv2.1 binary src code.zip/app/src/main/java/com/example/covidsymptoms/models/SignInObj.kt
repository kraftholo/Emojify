package com.example.covidsymptoms.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class SignInObj(
    @SerializedName("empid")
    @Expose
    var empId : Int,

    @SerializedName("password")
    @Expose
    var password : String
){
    override fun toString(): String {
        return "SignInObj(empId=$empId, password='$password')"
    }
}