package com.example.covidsymptoms.ui.main

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.covidsymptoms.R
import com.example.covidsymptoms.models.Question

/*
class GroupViewHolderRVAdapter(var subGroupQuestionList: List<String>) : RecyclerView.Adapter<QuestionListAdapter.CheckBoxTypeHolder>(){
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): QuestionListAdapter.CheckBoxTypeHolder {
        return QuestionListAdapter.CheckBoxTypeHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.layout_checkbox_list_item,
                parent,
                false
            ),
            null
        )
    }

    override fun getItemCount(): Int {
        return subGroupQuestionList.size
    }

    override fun onBindViewHolder(holder: QuestionListAdapter.CheckBoxTypeHolder, position: Int) {
        //Each subGroupQuestion will only be checkBox style with no children
        holder.bind(Question(
            viewType = 101,
            questionStr = subGroupQuestionList[position],
            editboxAns = "",
            checkboxAns = false,
            hasChildren = false,
            children = ArrayList(),                 //empty lists
            spinnerStr = ArrayList(),
            selected_val = "",
            impactOnStatus = "orange"
        ))
    }

}*/
