package com.example.covidsymptoms.util

class ErrorHandling {

    companion object{

        const val NETWORK_TIMEOUT_OCCURED = "Looks like the server is taking too long to respond, this can be caused by either poor connectivity or an error with our servers. Please try again in a while."
        const val NETWORK_TIMEOUT_OCCURED_FIRST_REQUEST = "Looks like the server is taking too long to respond. Please try again in a while."
        const val ERROR_CHECK_NETWORK_CONNECTION = "Check network connection."
        const val UNABLE_TODO_OPERATION_WO_INTERNET = "This application requires internet connection. Please check your internet connectivity"

        const val UNABLE_TODO_OPERATION_WO_INTERNET_FIRST_REQUEST  = "Can't do that operation without an internet connection special case for first request"

        const val ERROR_UNKNOWN = "Unknown error"

        const val AUTHTOKEN_EXPIRED = "Token Expired"

        //generic string for internal server error code =107
        const val INTERNAL_SERVER_ERROR_MESSAGE = "Server is not responding. Please try again after sometime."

        //getLatestApiVersion
        const val GET_LATEST_API_VERSION_FAIL = "GetLatestApiVersion_Response Failed"                   //on this i show server not responding

        //getOrganisationList
        const val GET_ORG_LIST_FAIL = "GetOrganisationList_Response Failed"

        //Filling a (EmployeeID) not convertible to INT
        const val CONVERSION_ERROR_SIGN_IN = "Sign In Failed, invalid employee id"
        const val CONVERSION_ERROR_REG = "Registration Failed, invalid employee id"

        const val CONVERSION_ERROR_RESET_PWD = "Reset Failed, invalid employee id"

        //getQuestionnaire endpoint
        const val QUESTIONNAIRE_NOT_AVAILABLE = "Questionnaire Response OK, questionnaire not available"
        const val QUESTIONNAIRE_INTERNAL_SERVER_ERROR = "Questionnaire Response fail, Internal server error"

        //announcement endpoint
        const val ANNOUNCEMENT_INTERNAL_SERVER_ERROR = "Announcement Response fail, Internal server error"

        const val RESET_PASSWORD_102 = "Password reset failed, Kindly contact the GA team before attempting to reset."




        fun isNetworkError(msg: String): Boolean{
            when{
                msg.contains(NETWORK_TIMEOUT_OCCURED) -> return true
                else-> return false
            }
        }
    }
}