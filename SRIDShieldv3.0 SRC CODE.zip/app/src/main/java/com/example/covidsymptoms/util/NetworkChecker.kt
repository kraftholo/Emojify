package com.example.covidsymptoms.util

interface NetworkChecker{

    fun isConnectedToTheInternet() : Boolean
}