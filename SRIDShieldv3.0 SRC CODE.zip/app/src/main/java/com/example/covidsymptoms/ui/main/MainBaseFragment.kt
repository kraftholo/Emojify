package com.example.covidsymptoms.ui.main

import androidx.fragment.app.Fragment
import com.example.covidsymptoms.ui.auth.HelpFragment

//used later
open class MainBaseFragment : Fragment(),OnBackPressed{

    override fun onBackPressed() {
        val fragments = fragmentManager?.fragments
        if(fragments != null){
            for(fragment in fragments){
                if(fragment is ReportFragment){

                }
                if(fragment is HelpFragment){

                }
                if(fragment is UpdateSymptomsFragment){

                }
            }
        }
    }
}