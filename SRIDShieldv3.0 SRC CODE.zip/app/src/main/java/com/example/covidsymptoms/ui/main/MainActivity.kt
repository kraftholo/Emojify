package com.example.covidsymptoms.ui.main

import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.navigation.NavController
import androidx.navigation.NavDestination
import androidx.navigation.findNavController
import com.afollestad.materialdialogs.MaterialDialog
import com.afollestad.materialdialogs.customview.customView
import com.afollestad.materialdialogs.customview.getCustomView
import com.example.covidsymptoms.R
import com.example.covidsymptoms.models.EmpDetail
import com.example.covidsymptoms.repository.MainRepository
import com.example.covidsymptoms.session.SessionManager
import com.example.covidsymptoms.ui.BaseActivity
import com.example.covidsymptoms.ui.auth.AuthActivity
import com.example.covidsymptoms.ui.main.state.MainStateEvent
import com.example.covidsymptoms.util.Constants
import com.example.covidsymptoms.util.Constants.Companion.KEY_DATE
import com.example.covidsymptoms.util.Constants.Companion.KEY_LOGOUT
import com.example.covidsymptoms.util.Constants.Companion.KEY_STATUS
import com.example.covidsymptoms.util.Constants.Companion.PREFS_NAME
import com.example.covidsymptoms.util.DateUtils
import com.example.covidsymptoms.util.ErrorHandling
import com.example.covidsymptoms.util.cancelNextAlarm
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_update_symptoms.*

class MainActivity : BaseActivity(), NavController.OnDestinationChangedListener {

    private var announcementShownOnce = false
    private var isFirstRequest = true
    private var finishingActivity = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        MainRepository.setNetworkChecker(this)
        SessionManager.currentActivityOnTop = Constants.MAIN_ACT

        val vm: MainViewModel by viewModels()

        val healthStatus: String? = intent.getStringExtra(Constants.HEALTH_STATUS)
        val empDetails: EmpDetail? = intent.getParcelableExtra(Constants.EMP_DETAIL)
        val time : String? = intent.getStringExtra(Constants.LAST_FILLED_TIME)

        val resultMessage : String? = intent.getStringExtra(Constants.RESULT_MESSAGE)
        val resultMessageRedList : String? = intent.getStringExtra(Constants.RESULT_MESSAGE_REDLIST)

        Log.d("MainActivity", "SuccessFul SignIn with healthStatus - ${healthStatus}")      //would be null if questionnaire has to be filled

        empDetails?.let {
            vm.setEmployee(it)
        }

        time?.let {
            vm.setTime(it)
        }

        resultMessage?.let {
            vm.resultMessageFromAuth = it
        }

        resultMessageRedList?.let {
            vm.resultMessageRedListFromAuth = it
        }

        vm.setStateEvent(MainStateEvent.GetAnnouncementEvent(vm.currEmpDetail!!.orgName,isFirstRequest))

        findNavController(R.id.main_nav_host_fragment).addOnDestinationChangedListener(this)
        subscribeObservers()
    }

    private fun subscribeObservers() {
        val vm: MainViewModel by viewModels()

        //OBSERVING VIEWSTATE CHANGES
        vm.viewState?.observe(this, Observer { viewState ->
            viewState.updationFields.let {
                it?.let {
                    it.healthStatus?.let {
                        when (it) {
                            "none" -> {
                                //UpdateSymptomsFragment is executing call for GetQuestionsEvent
                            }

                            //if healthStatus was not "none" then it must be "red/green"
                            else -> {
                                Log.d("MainActivity", "Navigate to reportFragment and update sharedPrefs with status = ${it}, Date = ${DateUtils.getCurrentDate()}")
                                val sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                                var editor = sharedPreferences.edit()
                                editor.putString(KEY_STATUS,it)
                                editor.putString(KEY_DATE,DateUtils.getCurrentDate())
                                editor.apply()
                                val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager?
                                alarmManager?.cancelNextAlarm(this)

                                findNavController(R.id.main_nav_host_fragment).navigate(R.id.action_updateSymptomsFragment_to_reportFragment)
                                fragment_container.visibility = View.VISIBLE
                                showAnnouncementDialog()
                            }
                        }
                    }

                }

            }
        })
        //TODO() - retry button here          //fire get announcement again after turning isFirstRequest = false
        //OBSERVING DATASTATE (FOR error,data and response)
        vm.dataState?.observe(this, Observer {dataState ->
            //3 different errors -> n/w timeout , no questions available , internal server error managed by 1 TV
            //handling of any DataState.error() and DataState.data's response part done in BaseActivity  except for the following berfore onDataStateChange
            dataState.error?.peekContent().let {
                it?.let {
                    if(it.response.message == ErrorHandling.NETWORK_TIMEOUT_OCCURED_FIRST_REQUEST ){             //handling 2 specially coz network timeout error of update will be a simple dialog bo
                                                                                                               //here i can handle the showing of something other than the network timeout dialog
                        if(findNavController(R.id.main_nav_host_fragment).currentDestination?.id == R.id.updateSymptomsFragment){
                            fragment_container.visibility = View.VISIBLE
                            success_quesV.visibility = View.GONE
                            error_quesV.visibility= View.VISIBLE
                            error_quesTextV.visibility = View.VISIBLE
                            retryButton.visibility = View.VISIBLE
                            setRetryListener()
                            error_quesTextV.setText(R.string.launcher_nw_timeout_subtitle)
                            dataState.error?.getContentIfNotHandled()
                        }
                    }

                    //show "Sorry, No questionnaire avaiable"
                    if(it.response.message.equals(ErrorHandling.QUESTIONNAIRE_NOT_AVAILABLE)){
                        fragment_container.visibility = View.VISIBLE
                        success_quesV.visibility = View.GONE
                        error_quesV.visibility= View.VISIBLE
                        error_quesTextV.visibility = View.VISIBLE
                        retryButton.visibility = View.VISIBLE                                       //TODO() check this out in UI for dialogs
                        showAnnouncementDialog()
                        error_quesTextV.setText(R.string.error_null_ques_str)
                        setRetryListener()
                        dataState.error?.getContentIfNotHandled()
                    }

                    //show string for internal server error (only handled for getQuestionnaire like this,others show a dialog)
                    if(it.response.message.equals(ErrorHandling.QUESTIONNAIRE_INTERNAL_SERVER_ERROR)){
                        fragment_container.visibility = View.VISIBLE
                        success_quesV.visibility = View.GONE
                        error_quesV.visibility= View.VISIBLE
                        error_quesTextV.visibility = View.VISIBLE
                        retryButton.visibility = View.VISIBLE
                        showAnnouncementDialog()
                        setRetryListener()
                        error_quesTextV.setText(R.string.internal_server_error)
                        dataState.error?.getContentIfNotHandled()
                    }
                }
            }

            onDataStateChange(dataState)
            //The code to setViewState on getting list can be refactored to UpdateSymptomsFragment
            dataState.data?.let {dataState ->
                dataState.data?.let { event ->
                    event.getContentIfNotHandled()?.let {viewState ->
                        viewState.updationFields?.let {updationFields ->
                            updationFields.questionList?.let {
                                Log.d(
                                    "MainActivity",
                                    "QuestionList set to recyclerView : ${it}"
                                )
                                vm.setQuestionListData(it)
                                fragment_container.visibility = View.VISIBLE                                //stay on updateSymptoms fragment and show both dialogs
                                success_quesV.visibility = View.VISIBLE
                                error_quesV.visibility = View.INVISIBLE
                                showDialogs()
                            }

                            //null in case of getquestionnaire but exists in update response
                            updationFields.healthStatus?.let {
                                     vm.setStatus(it)
                            }
                        }


                        //set on response from update 101
                        viewState.resultMessage?.let {
                            vm.resultMessageFromAuth = it               //overwrite
                        }
                        viewState.resultMessageRedList?.let {
                            vm.resultMessageRedListFromAuth = it        //overwrite
                        }

                        //be with any code 101,102,107 (except 108)         101-> actual announcement, otherwise ""
                        viewState.announcement?.let {
                            vm.setAnnouncement(it)                      //set it to viewmodel for later use
                            doWorkAfterGetAnnouncementResponse(it)
                        }
                    }

                }

                dataState.response?.let {responseEvent ->
                    responseEvent.getContentIfNotHandled()?.let {
                        it.message?.let {
                            //handles authtoken expired for every request
                            if(it.equals(ErrorHandling.AUTHTOKEN_EXPIRED)){
                                SessionManager.logOut()
                            }
                        }
                    }

                }



            }
        })

        //OBSERVING SESSIONMANAGER TOKEN (if it turns null, i want logout)
        SessionManager.token.observe(this, Observer {
            if(it == null && !finishingActivity){
                navigateToSignInPage()
            }
        })
    }

    private fun setRetryListener(){
        retryButton.setOnClickListener {
            isFirstRequest = false
            val vm: MainViewModel by viewModels()
            vm.setStateEvent(MainStateEvent.GetAnnouncementEvent(
                vm.currEmpDetail!!.orgName,isFirstRequest
            ))
        }
    }

    private fun navigateToSignInPage(){
        val intent = Intent(this,AuthActivity::class.java)
        intent.putExtra(KEY_LOGOUT,true)
        startActivity(intent)
        finish()
        overridePendingTransition(0, 0)
    }

    //called whenever we want to show announcement independently, will show if not already shown
    private fun showAnnouncementDialog(){
        val vm: MainViewModel by viewModels()
        Log.d(
            "MainActivity",
            "showAnnouncementDialog() - ${vm.getCurrentViewStateOrNew().announcement}"
        )
        if(announcementShownOnce) return

        vm.getCurrentViewStateOrNew().announcement?.let {
                MaterialDialog(this).show {
                    customView(R.layout.layout_custom_admin_announcement)
                    getCustomView().findViewById<TextView>(R.id.announcement_messageTV).setText(it)
                    positiveButton(R.string.text_ok){
                        announcementShownOnce = true
                    }
                    cancelable(false)
                    cancelOnTouchOutside(false)
                }
        }
    }

   // Runs to show announcement first and then PDC              (if announcement ="" just show PDC)
    private fun showDialogs(){
       val vm: MainViewModel by viewModels()
        Log.d(
            "MainActivity",
            "showDialogs() - announcement = ${vm.getCurrentViewStateOrNew().announcement}"
        )
       vm.getCurrentViewStateOrNew().announcement?.let {
           if(it != ""){
               MaterialDialog(this).show {
                   customView(R.layout.layout_custom_admin_announcement)
                   getCustomView().findViewById<TextView>(R.id.announcement_messageTV).setText(it)
                   positiveButton(R.string.text_ok){
                       announcementShownOnce = true
                       showPDCDialog()
                   }
                   cancelable(false)
                   cancelOnTouchOutside(false)
               }
           }else{
               showPDCDialog()
           }
       }
    }

    private fun showPDCDialog(){
        Log.d(
            "MainActivity",
            "showDialogs()"
        )
        MaterialDialog(this).show {
            title(R.string.personal_data_collection_notice_title)
            message(R.string.personal_data_collection_message)
            positiveButton(R.string.text_agree)
            cancelable(false)
            cancelOnTouchOutside(false)
            negativeButton(R.string.text_disagree) {
                killActivity()
            }
        }
    }

    private fun killActivity(){
        finishingActivity = true
        SessionManager.logOut()
        finish()
    }

    private fun doWorkAfterGetAnnouncementResponse(announcement: String){
        val healthStatus: String? = intent.getStringExtra(Constants.HEALTH_STATUS)
        val empDetails: EmpDetail? = intent.getParcelableExtra(Constants.EMP_DETAIL)
        val time : String? = intent.getStringExtra(Constants.LAST_FILLED_TIME)

        Log.d("MainActivity","doWorkAfterGetAnnouncementResponse()- HealthStatus = $healthStatus, EmpDetails = $empDetails, lastFilledTime = $time")
        val vm: MainViewModel by viewModels()

        if(announcement == ""){                 //if error case or empty announcement was received i will not show the announcement dialog
            announcementShownOnce = true
        }
        //after getAnnouncement is received .. then i fire getQuestionnaire IFF i am staying on the UpdateSymptomsFragment

        //incoming from authactivity healthStatus can be "green/red" or "none"
        if(healthStatus!=null){                                                         // go to result screen and show dialog there
            vm.setStatus(healthStatus)    //set healthStatus to viewState
        }else{
            vm.setStateEvent(MainStateEvent.GetQuestionsEvent(
                vm.currEmpDetail!!.orgName,
                isFirstRequest
            ))
        }
    }

    override fun onResume() {
        super.onResume()
        if(DateUtils.getCurrentDate() != SessionManager.appStartDate){
            Log.e("MainActivity","App start date and current date are not the same")
            SessionManager.logOut()
        }
    }
    override fun displayProgressBar(bool: Boolean) {
        if (bool) {
            progress_bar.visibility = View.VISIBLE
        } else {
            progress_bar.visibility = View.GONE
        }
    }

    override fun onDestinationChanged(
        controller: NavController,
        destination: NavDestination,
        arguments: Bundle?
    ) {
        val vm: MainViewModel by viewModels()
        vm.cancelActiveJobs()
    }

    override fun isConnectedToTheInternet(): Boolean {
        val cm = application.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        try{
            return cm.activeNetworkInfo.isConnected
        }catch (e: Exception){
            Log.e(TAG, "isConnectedToTheInternet: ${e.message}")
        }
        return false
    }

    //This can be refactored later
    private var doubleBackToExitPressedOnce = false

    override fun onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            killActivity()
            return
        }

        Log.d("MainActivity"," Call for toast to show !!!")
        this.doubleBackToExitPressedOnce = true
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show()

        Handler().postDelayed(Runnable { doubleBackToExitPressedOnce = false }, 2000)
    }

    override fun onDestroy() {
        Log.e("MainActivity","onDestroy()")
        MainRepository.clearReferenceToActivity()
        super.onDestroy()
    }
}
