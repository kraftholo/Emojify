package com.example.covidsymptoms.api

import com.example.covidsymptoms.api.auth.AuthApiService
import com.example.covidsymptoms.api.main.MainApiService
import com.example.covidsymptoms.util.LiveDataCallAdapterFactory
import com.example.covidsymptoms.util.MyUrls
import com.example.covidsymptoms.util.MyOkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitBuilder {

    val retrofitBuilder : Retrofit.Builder by lazy {
                    Retrofit.Builder()
                        .client(MyOkHttpClient.getUnsafeOkHttpClient().build())
                        .baseUrl(MyUrls.BASE_URL)
                        .addConverterFactory(GsonConverterFactory.create())
                        .addCallAdapterFactory(LiveDataCallAdapterFactory())
    }

    val authApiService : AuthApiService by lazy {
        retrofitBuilder.build().create(AuthApiService::class.java)
    }

    val mainApiService : MainApiService by lazy {
        retrofitBuilder.build().create(MainApiService::class.java)
    }

    val notificationApiService : NotificationApiService by lazy {
        retrofitBuilder.build().create(NotificationApiService::class.java)
    }
}