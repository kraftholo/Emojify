package com.example.covidsymptoms.repository

import android.util.Log
import android.widget.Toast
import androidx.lifecycle.LiveData
import com.example.covidsymptoms.BuildConfig
import com.example.covidsymptoms.api.RetrofitBuilder
import com.example.covidsymptoms.api.auth.responses.GetAppVersionResponse
import com.example.covidsymptoms.api.auth.responses.GetOrgListResponse
import com.example.covidsymptoms.api.auth.responses.SignInResponse
import com.example.covidsymptoms.api.auth.responses.RegistrationResponse
import com.example.covidsymptoms.models.AuthToken
import com.example.covidsymptoms.models.RegistrationObj
import com.example.covidsymptoms.models.SignInObj
import com.example.covidsymptoms.session.SessionManager
import com.example.covidsymptoms.ui.DataState
import com.example.covidsymptoms.ui.Response
import com.example.covidsymptoms.ui.ResponseType
import com.example.covidsymptoms.ui.auth.state.AuthViewState
import com.example.covidsymptoms.util.*
import com.example.covidsymptoms.util.ErrorHandling.Companion.CONVERSION_ERROR_REG
import com.example.covidsymptoms.util.ErrorHandling.Companion.CONVERSION_ERROR_SIGN_IN
import com.example.covidsymptoms.util.ErrorHandling.Companion.GET_LATEST_API_VERSION_FAIL
import com.example.covidsymptoms.util.ErrorHandling.Companion.GET_ORG_LIST_FAIL
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import java.lang.NumberFormatException

object AuthRepository{

    private val TAG = "AuthRepository"

    private var nwChecker : NetworkChecker? = null

    private val isStaging = BuildConfig.IS_STAGING

    private var repositoryJob: Job? = null

    fun setNetworkChecker(networkChecker : NetworkChecker){
        nwChecker = networkChecker
     }

    fun clearReferenceToActivity(){
        nwChecker = null
    }

    fun getOrganisationListFromServer(
    ): LiveData<DataState<AuthViewState>>{
        return object : NetworkBoundResource<GetOrgListResponse,AuthViewState>(nwChecker!!.isConnectedToTheInternet()){
            override fun createCall(): LiveData<GenericApiResponse<GetOrgListResponse>> {
                return RetrofitBuilder.authApiService.getOrgList()
            }

            override suspend fun handleApiSuccessResponse(response: ApiSuccessResponse<GetOrgListResponse>) {
                Log.d(TAG, "handleApiSuccessResponse: ${response}")

                when(response.body.code){

                    101 -> {
                        onCompleteJob(DataState.data(
                            AuthViewState(orgListReceived = response.body.orgList)
                        ))
                    }

                    else ->{
                        onErrorReturn(GET_ORG_LIST_FAIL,false,false)            //will set a default value of SRID in orglist
                    }

                }

            }

            override fun setJob(job: Job) {
                Log.d(TAG, "resetting repository job")
                repositoryJob?.cancel()
                repositoryJob = job
            }

        }.asLiveData()
    }


    //When refactoring code use NBR defined method onErrorReturn() instead of  OnCompleteJob(DataState.error())
    fun getLatestAppVersion(
        userAgent : String,
        isAppFirstRequest: Boolean
    ): LiveData<DataState<AuthViewState>>{

        return object : NetworkBoundResource<GetAppVersionResponse,AuthViewState>(nwChecker!!.isConnectedToTheInternet(),isAppFirstRequest){
            override fun createCall(): LiveData<GenericApiResponse<GetAppVersionResponse>> {
                if(isStaging){
                    Log.e(TAG, "getLatestAppVersion createCall() - SRID-STG")
                    return RetrofitBuilder.authApiService.getLatestAppVersion("SRID-STG",userAgent)
                }
               return RetrofitBuilder.authApiService.getLatestAppVersion(userAgent)
            }

            override suspend fun handleApiSuccessResponse(response: ApiSuccessResponse<GetAppVersionResponse>) {
                Log.d(TAG, "handleApiSuccessResponse: ${response}")
                when(response.body.code){
                    101 ->{
                        onCompleteJob(DataState.data(
                            data = AuthViewState(latestVersion = response.body.version),
                            response = null
                        ))
                    }

                    else -> {
                        onErrorReturn(GET_LATEST_API_VERSION_FAIL,false,false)
                    }
                }
            }

            override fun setJob(job: Job) {
                Log.d(TAG, "resetting repository job")
                repositoryJob?.cancel()
                repositoryJob = job
            }

        }.asLiveData()
    }



    fun attemptSignIn(
      employeeID: String,
      password: String,
      orgName : String
    ): LiveData<DataState<AuthViewState>> {

        var org = orgName
        if(isStaging) org = org+"-STG"

        try {
            Integer.valueOf(employeeID)
        } catch ( e : NumberFormatException) {
            Log.e("AuthRepository","Precheck of employee id failed - not convertible to int!")
            return returnErrorResponse(CONVERSION_ERROR_SIGN_IN,ResponseType.Dialog())
        }

        return object : NetworkBoundResource<SignInResponse,AuthViewState>(nwChecker!!.isConnectedToTheInternet()){
            override fun createCall(): LiveData<GenericApiResponse<SignInResponse>> {
                return RetrofitBuilder.authApiService.signIn(
                    SessionManager.appStartDate,
                    org,
                    SignInObj(employeeID.toInt(),password)
                    )
            }

            override suspend fun handleApiSuccessResponse(response: ApiSuccessResponse<SignInResponse>) {
                Log.d(TAG, "handleApiSuccessResponse: ${response}")

                when (response.body.code) {
                    101 -> {
                        onCompleteJob(
                            DataState.data(
                                data = AuthViewState(
                                    registrationFields = null,
                                    healthStatus = response.body.healthStatus,
                                    empDetail = response.body.empDetails,
                                    time = response.body.time,
                                    authToken = AuthToken(response.header)      //should not be null but wont crash
                                ),
                                response = null
                            )
                        )
                    }

                    107 -> {
                        onErrorReturn(ErrorHandling.INTERNAL_SERVER_ERROR_MESSAGE,true,false)
                    }

                    else -> {
                        onErrorReturn(response.body.description,true,false)
                    }
                }
            }

            override fun setJob(job: Job) {
                Log.d(TAG, "resetting repository job")
                repositoryJob?.cancel()
                repositoryJob = job
            }

        }.asLiveData()
    }

    fun attemptRegistration(
        employeeID: String,
        orgName : String,
        password: String
    ) : LiveData<DataState<AuthViewState>>{

        var org = orgName
        if(isStaging) org = org+"-STG"

        Log.e("AuthRepository","employee id = $employeeID and length = ${employeeID.length}")

        try {
            Integer.valueOf(employeeID)
        } catch ( e : NumberFormatException) {
            Log.e("AuthRepository","Precheck of employee id failed - not convertible to int!")
            return returnErrorResponse(CONVERSION_ERROR_REG,ResponseType.Dialog())
        }

        return object : NetworkBoundResource<RegistrationResponse,AuthViewState>(nwChecker!!.isConnectedToTheInternet()){
            override fun createCall(): LiveData<GenericApiResponse<RegistrationResponse>> {
                return RetrofitBuilder.authApiService.register(SessionManager.appStartDate,org,
                    RegistrationObj(
                        employeeID.toInt(),
                        orgName,
                        password
                    )
                )
            }

            override suspend fun handleApiSuccessResponse(response: ApiSuccessResponse<RegistrationResponse>) {
                Log.d("AuthRepository","handleApiSuccessResponse - response = $response")
                when(response.body.code){
                    101 -> {
                        onCompleteJob(DataState.data(
                            data = AuthViewState(
                                registrationFields = null,
                                healthStatus = null,
                                empDetail = response.body.empDetails,
                                time = null
                            ),
                            response = Response(Constants.REG_101_MESSAGE,ResponseType.Dialog())
                        ))
                    }

                    107 -> {
                        onErrorReturn(ErrorHandling.INTERNAL_SERVER_ERROR_MESSAGE,true,false)
                    }

                    else -> {
                       onErrorReturn(response.body.description,true,false)
                    }
                }
            }

            override fun setJob(job: Job) {
                Log.d(TAG, "resetting repository job")
                repositoryJob?.cancel()
                repositoryJob = job
            }

        }.asLiveData()
    }

    //Use this if error in some fields BEFORE JOB to be started (no onComplete JOb in this)
    //Like checking if registration fields are right

    private fun returnErrorResponse(errorMessage: String, responseType: ResponseType): LiveData<DataState<AuthViewState>>{
        Log.e("AuthRepository", "returnErrorResponse: ${errorMessage}")

        return object: LiveData<DataState<AuthViewState>>(){
            override fun onActive() {
                super.onActive()
                value = DataState.error(
                    Response(
                        errorMessage,
                        responseType
                    )
                )
            }
        }
    }

    fun cancelActiveJobs(){
        Log.d(TAG, "AuthRepository: Cancelling on-going jobs...")
        repositoryJob?.cancel()
    }
}