package com.example.covidsymptoms.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


data class Question(

    @SerializedName("qid")
    @Expose
    var qID : Int,

    @SerializedName("viewtype")
    @Expose
    var viewType : Int,

    @SerializedName("questionstr")
    @Expose
    var questionStr: String,

    @SerializedName("answer")
    @Expose
    var answer: String,

    @SerializedName("haschildren")
    @Expose
    var hasChildren: Boolean,

    @SerializedName("children")
    @Expose
    var children: List<Question>,

    @SerializedName("spinstr")
    @Expose
    var spinnerStr: List<String>,

    @SerializedName("impactonstatus")
    @Expose
    var impactOnStatus : String

){
    override fun toString(): String {
        return "Question(viewType=$viewType, questionStr='$questionStr', answer='$answer', hasChildren=$hasChildren, children=$children, spinnerStr=$spinnerStr, impactOnStatus='$impactOnStatus')"
    }
}