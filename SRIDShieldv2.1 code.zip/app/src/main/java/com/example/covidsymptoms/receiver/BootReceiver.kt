package com.example.covidsymptoms.receiver

import android.app.AlarmManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.example.covidsymptoms.util.initializeAlarm
import com.example.covidsymptoms.util.initializeAlarmAfterReboot

class BootReceiver: BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
       // Toast.makeText(context, "onReceive() of BootReceiver was triggered!", Toast.LENGTH_LONG).show()
        if(intent.action == Intent.ACTION_BOOT_COMPLETED){
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager?
            alarmManager?.initializeAlarmAfterReboot(context)
            alarmManager?.initializeAlarm(context)                  //for next day (use case = user already filled and then reboots, so no notif and therefore next day will not be scheduled!)
        }

    }

}