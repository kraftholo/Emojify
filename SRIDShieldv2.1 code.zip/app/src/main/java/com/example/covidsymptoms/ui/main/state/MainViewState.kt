package com.example.covidsymptoms.ui.main.state

import com.example.covidsymptoms.models.EmpDetail
import com.example.covidsymptoms.models.Question

data class MainViewState(
    var updationFields: UpdationFields? = UpdationFields(),
    var announcement : String? = null
)

data class UpdationFields(
    var questionList: List<Question>? = ArrayList(),
    var healthStatus: String? = null
) {
    override fun toString(): String {
        return "UpdationFields(questionList=$questionList)"
    }
}