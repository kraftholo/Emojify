package com.example.covidsymptoms.api.main.responses

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class UpdationResponse (

    @SerializedName("code")
    @Expose
    var code: Int,

    @SerializedName("description")
    @Expose
    var description: String
){
    override fun toString(): String {
        return "UpdationResponse(code='$code', description='$description')"
    }
}