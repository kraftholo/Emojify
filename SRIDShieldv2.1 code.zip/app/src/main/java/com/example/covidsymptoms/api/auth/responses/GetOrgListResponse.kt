package com.example.covidsymptoms.api.auth.responses

import com.example.covidsymptoms.models.Organisation
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class GetOrgListResponse(

    @SerializedName("code")
    @Expose
    var code: Int,

    @SerializedName("description")
    @Expose
    var description: String,

    @SerializedName("orgs")
    @Expose
    var orgList: List<Organisation>
){
    override fun toString(): String {
        return "GetOrgListResponse(code=$code, description='$description', orgList=$orgList)"
    }
}