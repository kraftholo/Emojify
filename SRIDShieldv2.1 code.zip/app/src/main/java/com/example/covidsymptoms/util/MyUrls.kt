package com.example.covidsymptoms.util

object MyUrls {

    //TODO : set default url here
    var BASE_URL = "https://sbsdbindia.samsungcloud.tv/" ;

    fun setBaseUrl(str : String){
        BASE_URL = str
    }
}