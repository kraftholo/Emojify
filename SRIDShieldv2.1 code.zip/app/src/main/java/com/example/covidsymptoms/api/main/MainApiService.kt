package com.example.covidsymptoms.api.main

import androidx.lifecycle.LiveData
import com.example.covidsymptoms.api.main.responses.*
import com.example.covidsymptoms.models.UpdateQuestionnaireObj
import com.example.covidsymptoms.util.GenericApiResponse
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST

interface MainApiService {

    @GET("app?route=survey/user")
    fun getQuestionnaireFromServer(
        @Header("authtoken") token : String,
        @Header("orgname") orgName : String,
        @Header("ondate") date : String
    )   : LiveData<GenericApiResponse<GetQuestionnaireResponse>>

    @POST("app?route=updatesurvey/user")
    fun updateQuestionnaireDb(
        @Header("authtoken") token : String,
        @Header("orgname") orgName : String,
        @Header("ondate") date : String,
        @Body questionnaireResponseToSend: UpdateQuestionnaireObj
    ) : LiveData<GenericApiResponse<UpdationResponse>>

    @POST("app?route=announcement/user")
    fun getAnnouncement(
        @Header("authtoken") token : String,
        @Header("orgname") orgName : String,
        @Header("ondate") date : String
    ) : LiveData<GenericApiResponse<AnnouncementResponse>>

    @GET("asdasd")
    fun getUrgentAnnouncement(
        @Header("orgname") orgName : String
    ) : LiveData<GenericApiResponse<UrgentAnnouncementResponse>>

}