package com.example.covidsymptoms.worker

import android.content.Context
import androidx.work.Data
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.example.covidsymptoms.api.RetrofitBuilder
import com.example.covidsymptoms.util.Constants

class UrgentAnnouncementWorker(context: Context, params: WorkerParameters) : Worker(context,params) {
    override fun doWork(): Result {

        val appContext = applicationContext

        var urgentAnnouncementExists = false
        val currUserOrg =
            appContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
                .getString(Constants.KEY_CURRENT_USER_ORG, null)

        if (currUserOrg != null) {
            //make call to server
            val response = RetrofitBuilder.notificationApiService.getUrgentNotification(
                currUserOrg
            ).execute()

            if (response.isSuccessful) {

            }

        } else {
            return Result.success()
        }


        /*       if (response.isSuccessful) {
            val outputData = Data.Builder().putBoolean(Constants.KEY_URGENT_ANNOUNCEMENT_EXISTS,urgentAnnouncementExists).build()
            Result.success(outputData)
            return Result.success()
        } else {
            if (response.code() in (500..599)) {
                // try again if there is a server error
                return Result.retry()
            }
            return Result.failure()
        }
    }
*/  return Result.success()
    }
}