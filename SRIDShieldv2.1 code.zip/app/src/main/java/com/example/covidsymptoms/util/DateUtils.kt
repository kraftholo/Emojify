package com.example.covidsymptoms.util

import android.util.Log
import java.text.SimpleDateFormat
import java.util.*

class DateUtils {

    companion object {

        private val TAG: String = "DateUtils"

        fun getCurrentDate(): String {
            val calendar = Calendar.getInstance();
            val sdf = SimpleDateFormat("dd/MM/yyyy")
            try {
                val date = sdf.format(calendar.time)
                Log.d(TAG,"getCurrentDate() - $date")
                return date
            } catch (e: Exception) {
                throw Exception(e)
            }
        }

        fun dateTimeStamp(): String {
            val calendar = Calendar.getInstance();
            val simpleDateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm");
            val stamp = simpleDateFormat.format(calendar.time)
            Log.d(TAG,"dateTimeStamp() - $stamp")
            return stamp
        }

        //time in 24hr format
        fun getTime(): String {
            val calendar = Calendar.getInstance();
            val simpleDateFormat = SimpleDateFormat("HH:mm");
            val stamp = simpleDateFormat.format(calendar.time)
            Log.d(TAG,"getTime() - $stamp")
            return stamp
        }
    }


}