package com.example.covidsymptoms.ui.main

import android.util.Log
import androidx.lifecycle.LiveData
import com.example.covidsymptoms.models.EmpDetail
import com.example.covidsymptoms.models.Question
import com.example.covidsymptoms.repository.AuthRepository
import com.example.covidsymptoms.repository.MainRepository
import com.example.covidsymptoms.session.SessionManager

import com.example.covidsymptoms.ui.BaseViewModel
import com.example.covidsymptoms.ui.DataState
import com.example.covidsymptoms.ui.main.state.MainStateEvent
import com.example.covidsymptoms.ui.main.state.MainViewState
import com.example.covidsymptoms.util.AbsentLiveData
import com.example.covidsymptoms.util.Constants.Companion.CHECKBOX_TYPE
import com.example.covidsymptoms.util.Constants.Companion.EDITBOX_TYPE
import com.example.covidsymptoms.util.Constants.Companion.GROUP_TYPE
import com.example.covidsymptoms.util.Constants.Companion.SPINNER_TYPE
import com.example.covidsymptoms.util.DateUtils

class MainViewModel : BaseViewModel<MainStateEvent,MainViewState>(){

    var currEmpDetail : EmpDetail? = null
    var lastFilledTime: String? = null

    override fun handleStateEvent(stateEvent: MainStateEvent): LiveData<DataState<MainViewState>> {
        when(stateEvent){
            is MainStateEvent.UpdateEvent -> {
                Log.d("MainViewModel","UpdateEvent fired -> " +
                        "token = ${SessionManager.token.value} " +
                        "orgName = ${stateEvent.orgName}" +
                        "date = ${SessionManager.appStartDate}" +
                        "time = ${stateEvent.time}" +
                        "healthStatus - ${stateEvent.healthStatus}, " +
                        "questions = ${stateEvent.questionsList}")

                return MainRepository.updateServerDb(
                    SessionManager.token.value?.token!!,
                    stateEvent.orgName,
                    SessionManager.appStartDate,
                    stateEvent.time,
                    stateEvent.healthStatus,
                    stateEvent.questionsList
                )
            }

            is MainStateEvent.GetQuestionsEvent -> {
                Log.d("MainViewModel","GetQuestionsEvent fired ->  token = ${SessionManager.token.value}, orgname =${stateEvent.orgName}, date =${SessionManager.appStartDate} ")
                return MainRepository.getQuestionnaireFromServer(
                    SessionManager.token.value?.token!!,
                    stateEvent.orgName,
                    SessionManager.appStartDate,
                    stateEvent.isFirstRequest
                )
            }

            is MainStateEvent.GetAnnouncementEvent -> {
                Log.d("MainViewModel","GetAnnouncementEvent fired ->  token = ${SessionManager.token.value}, orgname =${stateEvent.orgName}, date =${SessionManager.appStartDate} ")
                return MainRepository.getAnnouncementFromServer(
                    SessionManager.token.value?.token!!,
                    stateEvent.orgName,
                    SessionManager.appStartDate,
                    stateEvent.isFirstRequest
                )
            }

            is MainStateEvent.None -> return AbsentLiveData.create()
        }
    }

    override fun initNewViewState(): MainViewState {
        return MainViewState()
    }


    fun setStatus(healthStatus : String){
        Log.d("MainViewModel","setStatus() - setting healthStatus if not blank  - ${healthStatus.toLowerCase().trim()}")
        val update = getCurrentViewStateOrNew()
        if(healthStatus.isNullOrBlank()) return
        update.updationFields?.healthStatus = healthStatus.toLowerCase().trim()
        _viewState.value = update
    }

    fun setAnnouncement(announcement :String){
        val update = getCurrentViewStateOrNew()
        update.announcement = announcement
        _viewState.value = update
    }

    fun setQuestionListData(questionList : List<Question>){
        Log.d("MainViewModel","setQuestionListData()")
        val update = getCurrentViewStateOrNew()
        update.updationFields?.questionList = questionList
        _viewState.value = update
    }

    fun setEmployee(empDetails:EmpDetail){
        Log.d("MainViewModel","setEmployee() - not in MainViewState,just viewmodel")
        currEmpDetail = empDetails
    }

    fun setTime(time: String){
        Log.d("MainViewModel","setLastFilledTime() - not in MainViewState,just viewmodel")
        lastFilledTime = time
    }

    fun cancelActiveJobs(){
        MainRepository.cancelActiveJobs()
    }

}