package com.example.covidsymptoms.ui.main.state

import com.example.covidsymptoms.models.Question

sealed class MainStateEvent {

    //on updateButtonClicked
    data class UpdateEvent(
        val orgName : String,
        val time : String,
        val healthStatus: String,
        val questionsList: List<Question>
    ) : MainStateEvent()

    //on start of mainActivity
    data class GetQuestionsEvent(
        val orgName: String,
        val isFirstRequest :Boolean
    ) : MainStateEvent()

    data class GetAnnouncementEvent(
        val orgName: String,
        val isFirstRequest :Boolean
    ) : MainStateEvent()

    class None : MainStateEvent()
}