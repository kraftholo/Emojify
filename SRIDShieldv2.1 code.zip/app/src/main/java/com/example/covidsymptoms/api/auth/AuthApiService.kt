package com.example.covidsymptoms.api.auth

import androidx.lifecycle.LiveData
import com.example.covidsymptoms.api.auth.responses.GetAppVersionResponse
import com.example.covidsymptoms.api.auth.responses.GetOrgListResponse
import com.example.covidsymptoms.api.auth.responses.SignInResponse
import com.example.covidsymptoms.api.auth.responses.RegistrationResponse
import com.example.covidsymptoms.models.RegistrationObj
import com.example.covidsymptoms.models.SignInObj
import com.example.covidsymptoms.util.GenericApiResponse
import retrofit2.http.*

interface AuthApiService {

    @GET("app?route=org/list")
    fun getOrgList() : LiveData<GenericApiResponse<GetOrgListResponse>>


    @POST("app?route=signin/user")
    fun signIn(
        @Header("ondate") date : String,
        @Header("orgname") orgName : String,
        @Body signInObj : SignInObj
    ) : LiveData<GenericApiResponse<SignInResponse>>

    @POST("app?route=register/user")
    fun register(
        @Header("ondate") date : String,
        @Header("orgname") orgName : String,
        @Body registrationObj: RegistrationObj
    ) : LiveData<GenericApiResponse<RegistrationResponse>>


    @GET ("app?route=app/version")
    fun getLatestAppVersion(
        @Header("appname") userAgent : String
    ) : LiveData<GenericApiResponse<GetAppVersionResponse>>

    //for staging server
    @GET ("app?route=app/version")
    fun getLatestAppVersion(
        @Header("orgname") orgName : String,
        @Header("appname") userAgent : String
    ) : LiveData<GenericApiResponse<GetAppVersionResponse>>

}