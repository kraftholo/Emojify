package com.example.covidsymptoms.api.main.responses

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


data class AnnouncementResponse(

    @SerializedName("code")
    @Expose
    var code: Int,

    @SerializedName("description")
    @Expose
    var description: String,

    @SerializedName("announcement")
    @Expose
    var announcement: String?


){
    override fun toString(): String {
        return "AnnouncementResponse(code=$code, description='$description', announcement='$announcement')"
    }
}