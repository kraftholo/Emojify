package com.samsung.covidsymptoms.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class UpdateQuestionnaireObj(

    @SerializedName("healthstatus")
    @Expose
    var healthStatus : String,

    @SerializedName("time")
    @Expose
    var time : String,

    @SerializedName("questions")
    @Expose
    var questions : List<Question>?

){
    override fun toString(): String {
        return "QuestionnaireResponse(healthStatus='$healthStatus', questions=$questions)"
    }
}