package com.samsung.covidsymptoms.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.OneTimeWorkRequest
import androidx.work.WorkManager
import com.samsung.covidsymptoms.worker.AlarmNotificationWorker

//called once per day
class AlarmReceiver: BroadcastReceiver() {
    lateinit var workManager: WorkManager

    override fun onReceive(context: Context, intent: Intent) {
        //triggered 8 am everyday
       // Toast.makeText(context, "onReceive() of AlarmReceiver() was triggered! Starting WorkManager", Toast.LENGTH_LONG).show()

        workManager = WorkManager.getInstance(context)
        val workRequest = OneTimeWorkRequest.Builder(AlarmNotificationWorker::class.java)
            .build()
        workManager.enqueue(workRequest)

    }

}