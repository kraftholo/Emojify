package com.samsung.covidsymptoms.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


data class Question(

    @SerializedName("qid")
    @Expose
    var qID : Int,

    @SerializedName("viewtype")
    @Expose
    var viewType : Int,

    @SerializedName("questionstr")
    @Expose
    var questionStr: String,

    @SerializedName("answer")
    @Expose
    var answer: String,

    @SerializedName("haschildren")
    @Expose
    var hasChildren: Boolean,

    @SerializedName("children")
    @Expose
    var children: List<Question>,

    @SerializedName("spinstr")
    @Expose
    var spinnerStr: List<String>,

    @SerializedName("impactonstatus")
    @Expose
    var impactOnStatus : String,

    @SerializedName("questionno")
    @Expose
    var questionNo : Int,


    @SerializedName("ismandatory")
    @Expose
    var isMandatory: Int,

    @SerializedName("depedencylist")
    @Expose
    var dependencyList : List<Int>?

){
    override fun toString(): String {
        return "Question(qID=$qID, viewType=$viewType, questionStr='$questionStr', answer='$answer', hasChildren=$hasChildren, children=$children, spinnerStr=$spinnerStr, impactOnStatus='$impactOnStatus', questionNo=$questionNo, isMandatory=$isMandatory, dependencyList=$dependencyList)"
    }
}