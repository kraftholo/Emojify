package com.samsung.covidsymptoms.models

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class EmpDetail(

    @SerializedName("name")
    @Expose
    var name : String,

    @SerializedName("empid")
    @Expose
    var empID : Int,

    @SerializedName("group")
    @Expose
    var group : String,

    @SerializedName("team")
    @Expose
    var team : String,

    @SerializedName("orgname")
    @Expose
    var orgName : String

) : Parcelable {
    override fun toString(): String {
        return "EmpDetail(name='$name', empID=$empID, group='$group', team='$team', orgName='$orgName')"
    }
}