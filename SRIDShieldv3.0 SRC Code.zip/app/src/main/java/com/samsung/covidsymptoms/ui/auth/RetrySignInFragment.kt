package com.samsung.covidsymptoms.ui.auth

import android.os.Bundle
import android.util.Log
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import com.samsung.covidsymptoms.R
import com.samsung.covidsymptoms.ui.auth.state.AuthStateEvent
import kotlinx.android.synthetic.main.fragment_retry_sigin.*
import kotlinx.android.synthetic.main.fragment_retry_sigin.retryButton


class RetrySignInFragment : Fragment() {

    private var flag = false                                //ensures that if nothing visible till now , help fragment will not be shown ( as it cancels on going jobs)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        return inflater.inflate(R.layout.fragment_retry_sigin, container, false)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setHasOptionsMenu(true)
        val viewModel: AuthViewModel by activityViewModels()

        retryButton.setOnClickListener {
            //firing event for getLatestApiVersion
            viewModel.setStateEvent(AuthStateEvent.GetLatestAppVersion("android.app.version",false))
        }

        subscribeObservers()

    }

    private fun subscribeObservers(){
        val vm: AuthViewModel by activityViewModels()



        vm.retryButtonVisibility.observe(viewLifecycleOwner, Observer {
            it?.let { isVisible ->
                flag = true
                if(isVisible) {
                    retryButton.visibility = View.VISIBLE
                }else{
                    retryButton.visibility = View.INVISIBLE
                }
            }
        })

        vm.visibleTV.observe(viewLifecycleOwner, Observer {
            it?.let { visibleTV ->
                when(visibleTV){
                    "nw_timeout" -> {
                        subTitleTV_nw_timeout.visibility = View.VISIBLE
                        subTitleTV_nw_required.visibility= View.INVISIBLE
                        subTitleTV_update_app.visibility = View.INVISIBLE
                        subTitleTV_getLatestApiError.visibility = View.INVISIBLE
                    }

                    "update_app" -> {
                        subTitleTV_nw_timeout.visibility = View.INVISIBLE
                        subTitleTV_nw_required.visibility= View.INVISIBLE
                        subTitleTV_update_app.visibility = View.VISIBLE
                        subTitleTV_getLatestApiError.visibility = View.INVISIBLE
                    }

                    "internet_required" -> {
                        subTitleTV_nw_timeout.visibility = View.INVISIBLE
                        subTitleTV_nw_required.visibility= View.VISIBLE
                        subTitleTV_update_app.visibility = View.INVISIBLE
                        subTitleTV_getLatestApiError.visibility = View.INVISIBLE
                    }

                    "server_not_responding" -> {
                        subTitleTV_nw_timeout.visibility = View.INVISIBLE
                        subTitleTV_nw_required.visibility= View.INVISIBLE
                        subTitleTV_update_app.visibility = View.INVISIBLE
                        subTitleTV_getLatestApiError.visibility = View.VISIBLE
                    }
                }

            }
        })

    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.launcher_menu, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_help -> {
                Log.d("RetrySignInFragment", "Opening HelpFragment")
                if(flag) findNavController().navigate(R.id.action_retrySignInFragment_to_helpFragment)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}

