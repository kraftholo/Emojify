package com.samsung.covidsymptoms.ui.auth.state

import com.samsung.covidsymptoms.models.AuthToken
import com.samsung.covidsymptoms.models.EmpDetail
import com.samsung.covidsymptoms.models.Organisation

data class AuthViewState(
    var registrationFields: RegistrationFields? = RegistrationFields(),
    var signInFields: SignInFields? = SignInFields(),
    var healthStatus: String? = null,
    var empDetail: EmpDetail? = null,
    var time: String? = null,
    var authToken: AuthToken? = null,
    var latestVersion : String? = null,
    var orgListReceived: List<Organisation>? =null,

    var resultMessage : String? =null,
    var resultMessageRedList : String? = null
)

data class SignInFields(
    val signin_username: String? = null,
    val signin_password: String? = null
) {
    class SignInError {
        companion object {

            fun mustFillAllFields(): String {
                return "All fields are required !"
            }

            fun none(): String {
                return "None"
            }
        }
    }

    fun isValidForSignIn(): String {
        if (signin_username.isNullOrBlank() || signin_password.isNullOrBlank()) {
            return SignInError.mustFillAllFields()
        }
        return SignInError.none()
    }
}


data class RegistrationFields(
    val registration_employeeID: String? = null,
    val registration_password: String? = null,
    val registration_confirmPassword: String? = null
) {

    class RegistrationError {
        companion object {

            fun mustFillAllFields(): String {
                return "All fields are required !"
            }

            fun mustContainCondition(): String {
                return "Password must have at least 8 characters and maximum of 15 characters with at least one Capital letter, at least one lower case letter and at least one number"
            }

            fun passwordsDoNotMatch(): String {
                return "Passwords must match."
            }

            fun empIdToBeNumeric(): String {
                return "Employee ID must be numeric !"
            }

            fun none(): String {
                return "None"
            }

        }
    }

    fun isValidForRegistration(): String {

        if (registration_employeeID.isNullOrBlank() || registration_password.isNullOrBlank() || registration_confirmPassword.isNullOrBlank()) {
            return RegistrationError.mustFillAllFields()
        }

        if (!registration_employeeID.matches(Regex("[0-9]+"))) {
            return RegistrationError.empIdToBeNumeric()
        }

        if (registration_password != registration_confirmPassword) {
            return RegistrationError.passwordsDoNotMatch()
        }

        if (!registration_password!!.matches(Regex("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d!$%@#£€*?&]{8,15}$"))) {
            return RegistrationError.mustContainCondition()
        }

        return RegistrationError.none()
    }
}

data class UpdatePasswordFields(
    val updatePwd_employeeID: String? = null,
    val updatePwd_password: String? = null,
    val updatePwd_confirmPassword: String? = null
) {

    class UpdatePasswordError {
        companion object {

            fun mustFillAllFields(): String {
                return "All fields are required !"
            }

            fun mustContainCondition(): String {
                return "Password must have at least 8 characters and maximum of 15 characters with at least one Capital letter, at least one lower case letter and at least one number"
            }

            fun passwordsDoNotMatch(): String {
                return "Passwords must match."
            }

            fun empIdToBeNumeric(): String {
                return "Employee ID must be numeric !"
            }

            fun none(): String {
                return "None"
            }

        }
    }

    fun isValidForUpdation(): String {

        if (updatePwd_employeeID.isNullOrBlank() || updatePwd_password.isNullOrBlank() || updatePwd_confirmPassword.isNullOrBlank()) {
            return UpdatePasswordError.mustFillAllFields()
        }

        if (!updatePwd_employeeID.matches(Regex("[0-9]+"))) {
            return UpdatePasswordError.empIdToBeNumeric()
        }

        if (updatePwd_password != updatePwd_confirmPassword) {
            return UpdatePasswordError.passwordsDoNotMatch()
        }

        if (!updatePwd_password!!.matches(Regex("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d!$%@#£€*?&]{8,15}$"))) {
            return UpdatePasswordError.mustContainCondition()
        }

        return UpdatePasswordError.none()
    }
}
