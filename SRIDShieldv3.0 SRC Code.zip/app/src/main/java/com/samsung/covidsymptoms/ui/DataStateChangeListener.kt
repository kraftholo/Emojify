package com.samsung.covidsymptoms.ui

interface DataStateChangeListener{

    fun onDataStateChange(dataState: DataState<*>?)

    fun hideSoftKeyboard()
}