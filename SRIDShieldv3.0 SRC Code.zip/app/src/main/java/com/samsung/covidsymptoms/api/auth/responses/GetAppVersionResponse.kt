package com.samsung.covidsymptoms.api.auth.responses
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class GetAppVersionResponse(

    @SerializedName("version")
    @Expose
    var version: String,

    @SerializedName("description")
    @Expose
    var description: String,

    @SerializedName("code")
    @Expose
    var code : Int
)