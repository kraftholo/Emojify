package com.samsung.covidsymptoms.ui.auth

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.navigation.NavController
import androidx.navigation.NavDestination
import androidx.navigation.findNavController

import com.afollestad.materialdialogs.MaterialDialog
import com.samsung.covidsymptoms.BuildConfig
import com.samsung.covidsymptoms.R
import com.samsung.covidsymptoms.encyption.CipherWrapper
import com.samsung.covidsymptoms.encyption.KeyStoreWrapper
import com.samsung.covidsymptoms.models.Organisation
import com.samsung.covidsymptoms.repository.AuthRepository
import com.samsung.covidsymptoms.session.SessionManager
import com.samsung.covidsymptoms.ui.BaseActivity
import com.samsung.covidsymptoms.ui.auth.state.AuthStateEvent
import com.samsung.covidsymptoms.ui.main.MainActivity
import com.samsung.covidsymptoms.util.*
import com.samsung.covidsymptoms.util.Constants.Companion.CHANNEL_ID
import com.samsung.covidsymptoms.util.Constants.Companion.CHANNEL_NAME
import com.samsung.covidsymptoms.util.Constants.Companion.KEY_ALARM_SET
import com.samsung.covidsymptoms.util.Constants.Companion.KEY_IS_KEYPAIR_GENERATED
import com.samsung.covidsymptoms.util.Constants.Companion.KEY_LOGOUT
import com.samsung.covidsymptoms.util.Constants.Companion.PREFS_NAME
import com.samsung.covidsymptoms.util.ErrorHandling.Companion.GET_LATEST_API_VERSION_FAIL
import com.samsung.covidsymptoms.util.ErrorHandling.Companion.GET_ORG_LIST_FAIL
import kotlinx.android.synthetic.main.activity_auth.*


class AuthActivity : BaseActivity(), NavController.OnDestinationChangedListener {

    private var launcherPageShown  = false
    private var loggedOut = false
    private var versionNotInt = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auth)
        AuthRepository.setNetworkChecker(this)
        val viewModel: AuthViewModel by viewModels()
        Log.e(TAG, "Viewmodel - ${viewModel.hashCode()}")

        SessionManager.appStartDate = DateUtils.getCurrentDate()
        SessionManager.currentActivityOnTop = Constants.AUTH_ACT

        //Date is taken from SessionManager which inits it by lazy so its fixed during app's lifecycle
        Log.e(TAG, "Date - ${SessionManager.appStartDate}")

        //setting alarm for nextDay 8am
        setAndCheckAlarm()

        //setting keypair first time
        setAndCheckKeyPair()

        //when launched from mainActivity
        loggedOut = intent.getBooleanExtra(KEY_LOGOUT,false)
        if(loggedOut){
            //make call to get orglist
            //reinitialize if logged out
            viewModel.setStateEvent(AuthStateEvent.GetOrganisationListEvent())
        }else{
            //fire event to check for app version
            SessionManager.logOut()
            viewModel.setStateEvent(AuthStateEvent.GetLatestAppVersion("android.app.version",true))
        }

        createChannel(CHANNEL_ID, CHANNEL_NAME)
        findNavController(R.id.auth_nav_host_fragment).addOnDestinationChangedListener(this)
        subscribeObservers()
    }

    private fun setAndCheckKeyPair(){
        //master keypair stored in Android Keystore
        val sharedPreferences = getSharedPreferences(PREFS_NAME,MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val isKeyPairGenerated = sharedPreferences.getBoolean(KEY_IS_KEYPAIR_GENERATED,false)
        Log.e("AuthActivity", "setAndCheckKeyPair() - isKeyPairGenerated = $isKeyPairGenerated")

        if(!isKeyPairGenerated){
            val keyStoreWrapper = KeyStoreWrapper(this)
            keyStoreWrapper.createAndroidKeyStoreAsymmetricKey(Constants.MASTER_KEY)
            editor.putBoolean(KEY_IS_KEYPAIR_GENERATED,true)
            editor.apply()
        }
    }

    private fun showDialogForTokenExpiry(){
        MaterialDialog(this).show {
            title(R.string.text_error)
            message(R.string.session_expired)
            positiveButton(R.string.text_ok)
            cancelOnTouchOutside(false)
        }
    }

    //Runs when user opens app first time -> sets an alarm for next day 8am  + sets an alarm for today currentTime+2hr
    private fun setAndCheckAlarm(){
        val sharedPreferences = getSharedPreferences(PREFS_NAME,MODE_PRIVATE)
        val isAlarmSet = sharedPreferences.getBoolean(KEY_ALARM_SET,false)
        Log.e("AuthActivity", "checkAndSetAlarm() - isAlarmSet = $isAlarmSet")
        if(!isAlarmSet){
            val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager?
            alarmManager?.initializeAlarm(this)
            alarmManager?.setNextAlarm(this)
        }
    }

    private fun createChannel(channelId:String, channelName: String){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            val notificationChannel = NotificationChannel(channelId,channelName,
                NotificationManager.IMPORTANCE_HIGH)

            notificationChannel.enableVibration(true)
            notificationChannel.lightColor = Color.RED
            notificationChannel.enableLights(true)
            // notificationChannel.description = "Time for survey"

            val notificationManager = getSystemService(NotificationManager::class.java)

            notificationManager.createNotificationChannel(notificationChannel)
        }
    }

    private fun getOrgNameFromSharedPref() : String? {
        val keyStoreWrapper = KeyStoreWrapper(this)
        val sharedPreferences = getSharedPreferences(Constants.PREFS_NAME,Context.MODE_PRIVATE)

        val masterKey = keyStoreWrapper.getAndroidKeyStoreAsymmetricKeyPair(Constants.MASTER_KEY)
        val cipherWrapper = CipherWrapper(CipherWrapper.TRANSFORMATION_ASYMMETRIC)

        val savedOrgName = sharedPreferences.getString(Constants.KEY_ORGNAME,null)
        val decryptedOrgName = savedOrgName?.let {
            cipherWrapper.decrypt(it,masterKey?.private)
        }

        return decryptedOrgName
    }

    private fun subscribeObservers() {
        val vm: AuthViewModel by viewModels()

        vm.dataState.observe(this, Observer { dataState ->

            /*      This part of code is needed iff a network call is required at the start of application and it's result is crucial for app UI state,
                     like previously, the appUI state was dependent on the response to Sign In request to server ( and it was auto signin)*/

            //Had to put 3 different error textviews as the text was not updating

            //handling of any DataState.error() and DataState.data's response part done in BaseActivity  except for the following before onDataStateChange
            dataState.error?.peekContent().let {
                it?.let {
                    if(it.response.message == ErrorHandling.NETWORK_TIMEOUT_OCCURED_FIRST_REQUEST
                        ||it.response.message == ErrorHandling.NETWORK_TIMEOUT_OCCURED
                    ){
                        if(findNavController(R.id.auth_nav_host_fragment).currentDestination?.id == R.id.retrySignInFragment ){     //timeout during sigin or register will result in a simple dialog
                            fragment_container.visibility = View.VISIBLE
                            vm.setVisibleTextView("nw_timeout")
                            vm.setRetryButtonVisibility(true)

                            if(it.response.message == ErrorHandling.NETWORK_TIMEOUT_OCCURED_FIRST_REQUEST) dataState.error?.getContentIfNotHandled()
                            //consume it
                        }
                    }
                    //case when n/w timeout TV is showing and now retry and get no internet
                    //special cases
                    if(it.response.message == ErrorHandling.UNABLE_TODO_OPERATION_WO_INTERNET_FIRST_REQUEST||
                        it.response.message == ErrorHandling.UNABLE_TODO_OPERATION_WO_INTERNET ){
                        fragment_container.visibility = View.VISIBLE
                        vm.setVisibleTextView("internet_required")
                        vm.setRetryButtonVisibility(true)

                        if(it.response.message == ErrorHandling.UNABLE_TODO_OPERATION_WO_INTERNET_FIRST_REQUEST) dataState.error?.getContentIfNotHandled()
                    }

                    if(it.response.message.equals(GET_LATEST_API_VERSION_FAIL,true)){
                        fragment_container.visibility = View.VISIBLE
                        vm.setVisibleTextView("server_not_responding")
                        vm.setRetryButtonVisibility(true)
                        dataState.error?.getContentIfNotHandled()
                    }


                    if(it.response.message.equals(GET_ORG_LIST_FAIL,true)){
                        val orgNameSaved = getOrgNameFromSharedPref()
                        //if orgList fails to come from server, check in shared pref for a saved one, if that also empty, show error

                        if(orgNameSaved!=null){
                            val defaultList = ArrayList<Organisation>()
                            defaultList.add(
                                Organisation(
                                    orgName = orgNameSaved
                                ))
                            vm.setOrganisationList(defaultList)
                        }else{
                            fragment_container.visibility = View.VISIBLE
                            vm.setVisibleTextView("server_not_responding")
                            vm.setRetryButtonVisibility(true)
                            dataState.error?.getContentIfNotHandled()
                        }
                    }
                }
            }

            onDataStateChange(dataState)                                            //Handles all other cases like sign in 102,103,107 and register 102,103,107

            dataState.data?.let { data ->
                data.data?.let { event ->
                    event.getContentIfNotHandled()?.let {avs ->

                        avs.latestVersion?.let {
                            vm.setLatestAppVersion(it)
                        }

                        avs.orgListReceived?.let {
                            vm.setOrganisationList(it)
                        }

                        //signIn 101
                        avs.healthStatus?.let {healthStatus ->
                            when (healthStatus) {
                                "none" -> {
                                    //not setting healthStatus to "none" as mainactivity has a check for healthStatus == null or not
                                    avs.time?.let {vm.setLastFilledTime(it)}
                                    avs.empDetail?.let {vm.setEmpDetails(it)  }
                                }
                                else -> {
                                    vm.setHealthStatus(healthStatus)
                                    avs.time?.let {vm.setLastFilledTime(it) }
                                    avs.empDetail?.let {  vm.setEmpDetails(it) }                    //will never happen btw (see authrepository)

                                    avs.resultMessage?.let { vm.setResultMessage(it) }
                                    avs.resultMessageRedList?.let {vm.setResultMessageRedList(it) }
                                }
                            }
                        }

                        //set token in viewmodel
                        avs.authToken?.let {
                            Log.e("AuthActivity","DataState: ${it}")
                            vm.setAuthToken(it)
                        }

                        //case for successful registration
                        if(avs.healthStatus == null && avs.empDetail!=null){
                            Log.e("AuthActivity", "Successful Register! - navigating to signInfragment")
                            findNavController(R.id.auth_nav_host_fragment).let{
                                it.navigate(R.id.action_registerFragment_to_signInFragment)
                            }
                        }
                    }
                }
            }
        })

        //How the token flow works ->
        /* -    Any network request response when returned in the form of authViewState
                will have an AuthToken in it
            -   If the authtoken received is not null, i set it to the sessionManger token
            -   The SessionManager token is observed here and if it is not null indeed,
                i navigate to Mainactivity
        * */
        vm.viewState.observe(this,Observer{                             //careful here, after signIn time,empdetails,healthStatus changes will be not null here
            it.authToken?.let {
                SessionManager.login(it)
            }

            it.orgListReceived?.let {
                //call further from here
                if(!launcherPageShown){                               //laucherPageShown flag ensures that on futher change of viewState (like authtoken,sessionmanagertoken etc. it will not trigger)
                    if(loggedOut){
                        findNavController(R.id.auth_nav_host_fragment).let {
                            it.navigate(R.id.action_retrySignInFragment_to_launcherFragment)
                            it.navigate(R.id.action_launcherFragment_to_signInFragment)
                        }
                        fragment_container.visibility = View.VISIBLE
                        launcherPageShown = true
                        showDialogForTokenExpiry()
                    }else{
                        findNavController(R.id.auth_nav_host_fragment).navigate(R.id.action_retrySignInFragment_to_launcherFragment)
                        launcherPageShown = true
                        fragment_container.visibility = View.VISIBLE
                    }

                }
            }

            it.latestVersion?.let {
                if(!launcherPageShown){
                    //check if app versions are same
                    val shouldProceed = checkVersions(it)
                    //Yes -> proceed normally to launcher fragment
                    //No ->  make retry button invisible and change textview to update the app
                    if(shouldProceed){
                        //make call for getting orgList
                        vm.setStateEvent(AuthStateEvent.GetOrganisationListEvent())                     //its success and failure both set a list to the viewState thus invoking its observer
                    }else{
                        fragment_container.visibility = View.VISIBLE
                        if(versionNotInt){
                            vm.setVisibleTextView("server_not_responding")
                            vm.setRetryButtonVisibility(true)
                        }else{
                            vm.setVisibleTextView("update_app")
                            vm.setRetryButtonVisibility(false)
                        }
                    }
                }

            }
        })

        SessionManager.token.observe(this, Observer {
            it?.let {
                Log.e("AuthActivity","SessionManager token is - ${SessionManager.token.value}")
                navMainActivity()
            }
        })

    }

    private fun checkVersions(versionReceived : String):Boolean{
        Log.e("AuthActivity", "checkVersions() - versionReceived = $versionReceived")
        try {
            Integer.valueOf(versionReceived)
        } catch ( e : NumberFormatException) {
            Log.e("AuthActivity","version id not convertible to int!")
            versionNotInt = true
            return false
        }

        val versionCodeReceived = versionReceived.toInt()
        if(versionCodeReceived > BuildConfig.VERSION_CODE) return false            //server sends 201 and user has 200, show update app!
        return true
    }

    private fun navMainActivity(){
        val vm: AuthViewModel by viewModels()
        Log.d("AuthActivity", "navMainActivity()")
        val intent = Intent(this,MainActivity::class.java)
        intent.putExtra(Constants.HEALTH_STATUS,vm.getCurrentViewStateOrNew().healthStatus )
        intent.putExtra(Constants.EMP_DETAIL,vm.getCurrentViewStateOrNew().empDetail )
        intent.putExtra(Constants.LAST_FILLED_TIME,vm.getCurrentViewStateOrNew().time)

        intent.putExtra(Constants.RESULT_MESSAGE,vm.getCurrentViewStateOrNew().resultMessage)
        intent.putExtra(Constants.RESULT_MESSAGE_REDLIST,vm.getCurrentViewStateOrNew().resultMessageRedList)

        startActivity(intent)
        finish()
        overridePendingTransition(0, 0)
    }

    override fun isConnectedToTheInternet(): Boolean {
        val cm = application.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        try{
            return cm.activeNetworkInfo.isConnected
        }catch (e: Exception){
            Log.e(TAG, "isConnectedToTheInternet: ${e.message}")
        }
        return false
    }


    override fun displayProgressBar(bool: Boolean) {
        if (bool) {
            progress_bar.visibility = View.VISIBLE
        } else {
            progress_bar.visibility = View.GONE
        }
    }

    //If user navigates to other fragment b/w a network request
    override fun onDestinationChanged(
        controller: NavController,
        destination: NavDestination,
        arguments: Bundle?
    ) {
        val vm: AuthViewModel by viewModels()
        vm.cancelActiveJobs()

    }

    //nice way to implement on backpressed for a specific fragment
    override fun onBackPressed() {
        if(findNavController(R.id.auth_nav_host_fragment).currentDestination?.id == R.id.signInFragment){
            Log.e("AuthActivity","onBackPressed() for signInFragment")
            findNavController(R.id.auth_nav_host_fragment).navigate(R.id.action_signInFragment_to_launcherFragment)
            return
        }
        super.onBackPressed()

    }

    override fun onDestroy() {
        AuthRepository.clearReferenceToActivity()
        super.onDestroy()
    }
}
