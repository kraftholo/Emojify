package com.samsung.covidsymptoms.ui.main
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.annotation.LayoutRes
import com.samsung.covidsymptoms.R

class MySpinnerAdapter(context: Context, @LayoutRes private val layoutResource: Int, private val stringList: List<String>):
    ArrayAdapter<String>(context, layoutResource, stringList) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        return super.getView(position, convertView, parent)
    }

    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup?): View {
        if(position == 0){
            val goneTV = TextView(context)
            goneTV.visibility = View.GONE
            return goneTV
        }
        return createViewFromResource(position, convertView, parent)
    }

/*   override fun isEnabled(position: Int): Boolean {
        if(position == 0) return false                  //hint for spinner
       return super.isEnabled(position)
    }*/

    private fun createViewFromResource(position: Int, convertView: View?, parent: ViewGroup?): View{
        val view: TextView = convertView as TextView? ?: LayoutInflater.from(context).inflate(layoutResource, parent, false) as TextView

        val params = view.layoutParams
        params.height = context.resources.getDimension(R.dimen.dimen_50dp_h).toInt()
        view.layoutParams = params

        view.text = stringList[position]
        return view
    }
}