package com.samsung.covidsymptoms.session

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.samsung.covidsymptoms.models.AuthToken
import com.samsung.covidsymptoms.util.Constants
import com.samsung.covidsymptoms.util.DateUtils
import kotlinx.coroutines.Dispatchers.Main
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

object SessionManager{
    private val TAG = "SessionManager"

    private var _isInForeground : String? = null

    var currentActivityOnTop :String? = null

    var isInForeground : String? = null
        get() = _isInForeground

    var appStartDate  = DateUtils.getCurrentDate()          //initialize it

    private val _token = MutableLiveData<AuthToken>()

    val token : LiveData<AuthToken>
        get() = _token

    fun login(newValue : AuthToken){
        Log.e(TAG,"login() - token = ${token.value?.token}")
        setValue(newValue)
    }

    fun logOut(){
        setValue(null)
    }

    fun appInForeground(){
        _isInForeground = Constants.IN_FOREGROUND
    }

    fun appInBackground(){
        _isInForeground = Constants.IN_BACKGROUND
    }

    fun setValue(newValue:AuthToken?){
        GlobalScope.launch(Main) {
            if(_token.value != newValue){
            _token.value = newValue
        }
        }
    }
}