package com.samsung.covidsymptoms.api.main.responses

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class UpdationResponse (

    @SerializedName("code")
    @Expose
    var code: Int,

    @SerializedName("description")
    @Expose
    var description: String,

    @SerializedName("healthstatus")
    @Expose
    var healthStatus: String,

    @SerializedName("message")
    @Expose
    var message: String,

    @SerializedName("message_for_red_list_user")
    @Expose
    var messageRedListUser: String
){
    override fun toString(): String {
        return "UpdationResponse(code=$code, description='$description', healthStatus='$healthStatus', message='$message', messageRedListUser='$messageRedListUser')"
    }
}