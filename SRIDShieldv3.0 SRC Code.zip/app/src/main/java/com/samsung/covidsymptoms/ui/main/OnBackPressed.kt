package com.samsung.covidsymptoms.ui.main

//Used later
interface OnBackPressed{

    fun onBackPressed()
}