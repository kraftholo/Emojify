package com.samsung.covidsymptoms.api.auth.responses

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class UpdatePasswordResponse(

    @SerializedName("code")
    @Expose
    var code: Int,

    @SerializedName("description")
    @Expose
    var description: String,

    @SerializedName("empid")
    @Expose
    var empid: Int

){
    override fun toString(): String {
        return "UpdatePasswordResponse(code=$code, description=$description)"
    }
}