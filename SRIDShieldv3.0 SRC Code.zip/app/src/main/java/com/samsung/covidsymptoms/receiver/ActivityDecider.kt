package com.samsung.covidsymptoms.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import android.util.Log
import com.samsung.covidsymptoms.session.SessionManager
import com.samsung.covidsymptoms.ui.auth.AuthActivity
import com.samsung.covidsymptoms.ui.main.MainActivity
import com.samsung.covidsymptoms.util.Constants

class ActivityDecider : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        val currentActivity = SessionManager.currentActivityOnTop
        var intentToStartActivity : Intent

        //[crash case] => when app is running + in background => notification comes => app killed => notification clicked
        Log.e("ActivityDecider","currentActivity = $currentActivity")

        if(currentActivity != null ){
                //app is running, and in background on time of notifclick
                intentToStartActivity = when(currentActivity){
                    Constants.AUTH_ACT -> Intent(context,AuthActivity::class.java)
                    Constants.MAIN_ACT -> Intent(context,MainActivity::class.java)
                    else -> Intent(context,AuthActivity::class.java)                    //asks be exhaustive
                }
                intentToStartActivity.flags = FLAG_ACTIVITY_NEW_TASK
                context?.startActivity(intentToStartActivity)
        }else{
            //app is NOT running on time of notificationclick
            intentToStartActivity  = Intent(context,AuthActivity::class.java)
            intentToStartActivity.flags = FLAG_ACTIVITY_NEW_TASK
            context?.startActivity(intentToStartActivity)
        }
    }
}