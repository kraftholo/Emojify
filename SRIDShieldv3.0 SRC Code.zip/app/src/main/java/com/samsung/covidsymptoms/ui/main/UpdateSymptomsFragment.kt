package com.samsung.covidsymptoms.ui.main

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.afollestad.materialdialogs.MaterialDialog
import com.samsung.covidsymptoms.R
import com.samsung.covidsymptoms.models.Question
import com.samsung.covidsymptoms.ui.main.state.MainStateEvent
import com.samsung.covidsymptoms.util.Constants
import com.samsung.covidsymptoms.util.DateUtils
import com.samsung.covidsymptoms.util.TopSpacingItemDecoration
import kotlinx.android.synthetic.main.fragment_update_symptoms.*

class UpdateSymptomsFragment : Fragment(),QuestionListAdapter.Interaction {

    override fun onItemSelected(position: Int, item: Question) {
        //do nothing right now
    }

    val TAG = "UpdateSymptomsFragment"

    private lateinit var recyclerAdapter : QuestionListAdapter
    var healthStatus_calculated = "NotYet"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        /*    Returns a property delegate to access parent activity's ViewModel, if factoryProducer is specified
            then ViewModelProvider.Factory returned by it will be used to create ViewModel first time.Otherwise,
            the activity's androidx.activity.ComponentActivity.getDefaultViewModelProviderFactory will be used*/

        val viewModel: MainViewModel by activityViewModels()

        Log.d(TAG,"Viewmodel - ${viewModel.hashCode()}")
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        update_button.setOnClickListener {
            updateChangesToServer()
        }
        val vm: MainViewModel by activityViewModels()
        initRecyclerView()
        subscribeObservers()
    }

    private fun updateChangesToServer(){
        update_button.isFocusable = true
        update_button.isFocusableInTouchMode = true
        update_button.requestFocus()
        update_button.isFocusable = false
        update_button.isFocusableInTouchMode = false

        otherWork()
    }

    private fun otherWork() {
        val vm: MainViewModel by activityViewModels()

        val mandatoryQuesListHashSet = QuestionListAdapter.mandatoryQuesList.toHashSet()
        val quesList = ArrayList<Int>()
        quesList.addAll(mandatoryQuesListHashSet)
        quesList.sort()

        val errorDisplayString = "Please fill out the following questions before proceeding - \n"
        var quesStr = ""
        for(quesNo : Int in quesList){
            quesStr = quesStr + "Q-$quesNo\n"
        }

        Log.e("UpdateSymptomsFragment", "mandatoryQuesListHashSet = $quesList")

        if (quesList.size != 0) {
            questionRV.smoothScrollToPosition(quesList[0])
            MaterialDialog(context!!).show {
                title(R.string.text_error)
                message(text = errorDisplayString+quesStr)
                positiveButton(R.string.text_ok)
                cancelable(false)
            }
        } else {
            val healthStatus =
                recyclerAdapter.calculateHealthStatus()                  //runs the test
            Log.e("UpdateSymptomsFragment", " healthStatus = $healthStatus")
            healthStatus_calculated = healthStatus
            MaterialDialog(context!!).show {
                title(R.string.employee_undertaking_title)
                message(R.string.employee_undertaking_message)
                positiveButton(R.string.text_ok) {
                    //Toast.makeText(context,"The status to be sent is - $healthStatus",Toast.LENGTH_SHORT).show()
                    showDialogWithQuestionAnswers(false)
                    vm.setTime(DateUtils.getTime())
                    vm.setStateEvent(
                        MainStateEvent.UpdateEvent(
                            vm.currEmpDetail!!.orgName,
                            vm.lastFilledTime!!,
                            healthStatus,
                            vm.getCurrentViewStateOrNew().updationFields?.questionList!!
                        )
                    )
                }
                cancelable(false)
                cancelOnTouchOutside(false)
                negativeButton(R.string.text_cancel)
            }
        }
    }

    private fun showDialogWithQuestionAnswers(bool:Boolean){
        var string = ""
        for((index,ques) in  QuestionListAdapter.questions.withIndex()){
            if(ques.viewType == 104){
                string += "Q-${index+1} answer is = ${ques.answer}\n"
                string += "subValues = ${ques.children[0].answer},${ques.children[1].answer},${ques.children[2].answer},${ques.children[3].answer},${ques.children[4].answer},${ques.children[5].answer}, \n"
            }
            else if(ques.viewType == 101 && ques.hasChildren){
                string += "Q-${index+1} answer is = ${ques.answer}\n"
                string += "subvalue = ${ques.children[0].answer}\n"
            }else{
                string += "Q-${index+1} answer is = ${ques.answer}\n"
            }
        }
        string += "Status sent to server = $healthStatus_calculated"
        Log.d("UpdateSymptomsFragment","Result questionaire sent = $string")
        if(bool){
            MaterialDialog(context!!).show {
                title(text = "Info")
                message(text = string)
                positiveButton (R.string.text_ok)
            }
        }

    }


    private fun initRecyclerView(){
        questionRV.apply {
            layoutManager = LinearLayoutManager(this@UpdateSymptomsFragment.context)

            recyclerAdapter = QuestionListAdapter(this@UpdateSymptomsFragment)
            val topSpacingItemDecorator = TopSpacingItemDecoration(30)
            removeItemDecoration(topSpacingItemDecorator)
            addItemDecoration(topSpacingItemDecorator)
            adapter = recyclerAdapter
        }
    }

    private fun subscribeObservers(){
        val vm : MainViewModel by activityViewModels()

        vm.dataState.observe(viewLifecycleOwner, Observer {dataState ->
            dataState?.let {dataState ->
                dataState.data?.let {
                    it.response?.let {event ->
                        event.peekContent()?.let {response ->
                            if(response.message.equals(Constants.UPDATION_101,true)){
                               // vm.setStatus(healthStatus_calculated)
                            }
                        }
                    }
                }
            }
        })

        //changes after i change from mainactivity
        vm.viewState.observe(viewLifecycleOwner, Observer {viewState ->
            viewState?.let {
                it.updationFields?.let {
                    Log.d("UpdateSymptomsFragment","submit list - ${it.questionList}")
                    recyclerAdapter.submitList(it.questionList!!)
                }

            }
        })
    }

    override fun onDestroyView() {
        questionRV.adapter = null
        super.onDestroyView()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_update_symptoms, container, false)
    }

}
