import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import com.afollestad.materialdialogs.MaterialDialog
import com.afollestad.materialdialogs.customview.customView
import com.samsung.covidsymptoms.R
import com.samsung.covidsymptoms.models.Organisation
import com.samsung.covidsymptoms.ui.auth.AuthViewModel
import com.samsung.covidsymptoms.ui.auth.adapter.OrganizationSpinnerAdapter
import com.samsung.covidsymptoms.ui.auth.state.AuthStateEvent
import com.samsung.covidsymptoms.ui.auth.state.UpdatePasswordFields
import com.samsung.covidsymptoms.ui.displayErrorDialog
import com.samsung.covidsymptoms.util.Constants
import com.samsung.covidsymptoms.util.ErrorHandling
import kotlinx.android.synthetic.main.fragment_update_password.*

class ResetPasswordFragment : Fragment() {

    val TAG = "HelpFragment"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        /*    Returns a property delegate to access parent activity's ViewModel, if factoryProducer is specified
            then ViewModelProvider.Factory returned by it will be used to create ViewModel first time.Otherwise,
            the activity's androidx.activity.ComponentActivity.getDefaultViewModelProviderFactory will be used*/

        val viewModel: AuthViewModel by activityViewModels()
        Log.d(TAG, "Viewmodel - ${viewModel.hashCode()}")

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_update_password, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val viewModel: AuthViewModel by activityViewModels()
        subscribeObservers()
        showResetDialog()

        updatePwdButton.setOnClickListener {
            updatePassword()
        }
        val orgListInViewModel = viewModel.getCurrentViewStateOrNew().orgListReceived
        val spinnerList = ArrayList<String>()
        for( org : Organisation in orgListInViewModel!!){
            spinnerList.add(org.orgName)
        }
        Log.e("ResetPasswordFragment","spinnerlist is $spinnerList")

        activity?.let {
            val mAdapter = OrganizationSpinnerAdapter(it,R.layout.layout_org_spinner_option_row,spinnerList)
            orgSpinner.adapter = mAdapter
            orgSpinner.setSelection(0)
        }

    }

    private fun updatePassword(){
        val vm : AuthViewModel by activityViewModels()

        val updatePwdFieldsError = UpdatePasswordFields(
            update_pwd_employeeID.text.toString(),
            update_pwd_password.text.toString(),
            update_pwd_confirmPassword.text.toString()
        ).isValidForUpdation()

        if(updatePwdFieldsError != UpdatePasswordFields.UpdatePasswordError.none()){
            context!!.displayErrorDialog(updatePwdFieldsError)                           //Kotlin ViewExtensions used
        }
        else{
            vm.setStateEvent(AuthStateEvent.UpdatePasswordEvent(
                update_pwd_employeeID.text.toString(),
                update_pwd_password.text.toString(),
                orgSpinner.selectedItem.toString()
            ))
        }

    }

    private fun subscribeObservers(){
        val vm: AuthViewModel by activityViewModels()

        vm.dataState?.observe(viewLifecycleOwner, Observer {dataState ->

            dataState.data?.let {
                it.data?.let {event ->
                    it.response?.peekContent()?.let {           //peeking as i want the success dialog to also show
                        if(it.message == Constants.RESET_PASSWORD_101)
                            findNavController().navigate(R.id.action_resetPasswordFragment_to_signInFragment)
                    }
                }
            }

            dataState.error?.let {event ->
                event.peekContent().let {error ->
                    if(error.response.message == ErrorHandling.RESET_PASSWORD_102){
                        showCustomMessage102()
                        event.getContentIfNotHandled()          //consume
                    }
                }
            }
        })
    }

    private fun showCustomMessage102(){
        MaterialDialog(context!!).show {
            title(text = "Info")
            message(text = ErrorHandling.RESET_PASSWORD_102)
            positiveButton(R.string.text_ok)
            cancelOnTouchOutside(false)
        }
    }

    private fun showResetDialog(){
        MaterialDialog(context!!).show {
            customView(viewRes = R.layout.layout_update_password_dialog_view,horizontalPadding = true)
            positiveButton(R.string.text_ok)
            cancelOnTouchOutside(false)
        }
    }
}


