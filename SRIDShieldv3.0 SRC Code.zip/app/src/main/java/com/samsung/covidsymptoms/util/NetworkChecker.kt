package com.samsung.covidsymptoms.util

interface NetworkChecker{

    fun isConnectedToTheInternet() : Boolean
}