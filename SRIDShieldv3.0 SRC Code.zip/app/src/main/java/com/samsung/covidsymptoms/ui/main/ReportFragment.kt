package com.samsung.covidsymptoms.ui.main


import android.graphics.Typeface
import android.os.Bundle
import android.util.Log
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.samsung.covidsymptoms.BuildConfig
import com.samsung.covidsymptoms.R
import com.samsung.covidsymptoms.session.SessionManager
import com.samsung.covidsymptoms.util.Constants.Companion.COLOR_GREEN
import com.samsung.covidsymptoms.util.Constants.Companion.COLOR_RED
import com.samsung.covidsymptoms.util.DateUtils
import com.google.zxing.BarcodeFormat
import com.google.zxing.integration.android.IntentIntegrator
import com.journeyapps.barcodescanner.BarcodeEncoder
import kotlinx.android.synthetic.main.fragment_report.*

class ReportFragment : Fragment() {

    val TAG = "ReportFragment"

    lateinit var intentIntegrator: IntentIntegrator

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val viewModel: MainViewModel by activityViewModels()
        Log.d(TAG, "Viewmodel - ${viewModel.hashCode()}")

        activity?.let {
            intentIntegrator = IntentIntegrator(it)
        }

    }

    private fun initBarCode(){
        val viewModel: MainViewModel by activityViewModels()
        val barCodeEncoder = BarcodeEncoder()
      //  Log.d("ReportFragment","value of 1 dp = ${resources.getDimension(R.dimen.dimen_1dp_w)}")
        val testW = resources.displayMetrics.widthPixels - (resources.displayMetrics.widthPixels)/8.0
        val testH = resources.displayMetrics.heightPixels / 9.5

        val bitmap = barCodeEncoder.encodeBitmap(viewModel.currEmpDetail!!.empID.toString(),
                BarcodeFormat.CODE_128,testW.toInt(), testH.toInt()
            )
        barcodeIV.setImageBitmap(bitmap)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val viewModel: MainViewModel by activityViewModels()
        val empDetails =  viewModel.currEmpDetail

        initBarCode()

        greetingTV.setText("Hi ${empDetails?.name}," +
                "\nEMP ID:\t ${empDetails?.empID}" +
                "\nORG NAME:\t ${empDetails?.orgName}"
                )

        dateTimeInfoTV.setText( "SURVEY FILLED DATE:\t ${SessionManager.appStartDate}" +
                "\nSURVEY FILLED AT:\t ${viewModel.lastFilledTime} Hrs"+
        "\nCURRENT DEVICE TIME:\t ${DateUtils.getTime()} Hrs")

        if(viewModel.resultMessageRedListFromAuth == ""){
            special_messageTV.visibility = View.GONE
        }else{
            special_messageTV.setText("Reason: ${viewModel.resultMessageRedListFromAuth}")
        }

        messageTV.setText(viewModel.resultMessageFromAuth)

        val appName = resources.getString(R.string.app_name)

        helpLine.setText("Helpline no.\n+919717066884")
        validTillTV.setText("Valid till today\n11:59 p.m.")
        versionTV.setText("${appName} v${BuildConfig.VERSION_NAME}")



        //trim spaces and convert to lower case

        when (viewModel.getCurrentViewStateOrNew().updationFields?.healthStatus?.toLowerCase()?.trim()) {
            COLOR_RED -> {
                Log.d("ReportFragment", "color - $COLOR_RED")
                resultColorView.setBackgroundColor(resources.getColor(R.color.red))

                if(viewModel.resultMessageFromAuth == ""){                                                                      //for testing
                    messageTV.setText(R.string.red_indication_result)
                }

                messageTV.setTypeface(null,Typeface.BOLD)
                entryStatusIcon.setImageResource(R.drawable.prohibited)
                entryStatus.setText(R.string.red_result_title)
            }

            COLOR_GREEN -> {
                Log.d("ReportFragment", "color - $COLOR_GREEN")

                resultColorView.setBackgroundColor(resources.getColor(R.color.green))
                if(viewModel.resultMessageFromAuth == ""){                                                                      //for testing
                    messageTV.setText(R.string.green_indication_result)
                }
               // messageTV.setText(R.string.green_indication_result)
                special_messageTV.visibility = View.GONE
                entryStatusIcon.setImageResource(R.drawable.permitted)
                entryStatus.setText(R.string.green_result_title)
            }

            else -> {
                Log.e(
                    "ReportFragment",
                    "color - error with healthStatus being - ${viewModel.getCurrentViewStateOrNew().updationFields?.healthStatus}"
                )
                resultColorView.setBackgroundColor(resources.getColor(R.color.healthStatus_error))
                messageTV.setText("Please contact the helpdesk")
                entryStatus.setText("ERROR!")
                entryStatusIcon.visibility = View.GONE
                helpLine.setText("Helpline no. +919717066884 \n" +
                        "${appName} v${BuildConfig.VERSION_NAME}")
            }

        }

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_report, container, false)
    }
}