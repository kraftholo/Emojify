package com.samsung.covidsymptoms.repository

import android.util.Log
import androidx.lifecycle.LiveData
import com.samsung.covidsymptoms.BuildConfig
import com.samsung.covidsymptoms.api.RetrofitBuilder
import com.samsung.covidsymptoms.api.auth.responses.*
import com.samsung.covidsymptoms.models.AuthToken
import com.samsung.covidsymptoms.models.RegistrationObj
import com.samsung.covidsymptoms.models.SignInObj
import com.samsung.covidsymptoms.session.SessionManager
import com.samsung.covidsymptoms.ui.DataState
import com.samsung.covidsymptoms.ui.Response
import com.samsung.covidsymptoms.ui.ResponseType
import com.samsung.covidsymptoms.ui.auth.state.AuthViewState
import com.samsung.covidsymptoms.util.*
import com.samsung.covidsymptoms.util.ErrorHandling.Companion.CONVERSION_ERROR_REG
import com.samsung.covidsymptoms.util.ErrorHandling.Companion.CONVERSION_ERROR_RESET_PWD
import com.samsung.covidsymptoms.util.ErrorHandling.Companion.CONVERSION_ERROR_SIGN_IN
import com.samsung.covidsymptoms.util.ErrorHandling.Companion.GET_LATEST_API_VERSION_FAIL
import com.samsung.covidsymptoms.util.ErrorHandling.Companion.GET_ORG_LIST_FAIL
import kotlinx.coroutines.Job
import java.lang.NumberFormatException

object AuthRepository{

    private val TAG = "AuthRepository"

    private var nwChecker : NetworkChecker? = null

    private val isStaging = BuildConfig.IS_STAGING

    private var repositoryJob: Job? = null

    fun setNetworkChecker(networkChecker : NetworkChecker){
        nwChecker = networkChecker
     }

    fun clearReferenceToActivity(){
        nwChecker = null
    }

    fun getOrganisationListFromServer(
    ): LiveData<DataState<AuthViewState>>{
        return object : NetworkBoundResource<GetOrgListResponse,AuthViewState>(nwChecker!!.isConnectedToTheInternet()){
            override fun createCall(): LiveData<GenericApiResponse<GetOrgListResponse>> {
                return RetrofitBuilder.authApiService.getOrgList()
            }

            override suspend fun handleApiSuccessResponse(response: ApiSuccessResponse<GetOrgListResponse>) {
                Log.d(TAG, "handleApiSuccessResponse: ${response}")

                when(response.body.code){
                    101 -> {
                        onCompleteJob(DataState.data(
                            AuthViewState(orgListReceived = response.body.orgList)
                        ))
                    }

                   /* ErrorHandling
                   * --------------
                   * Done in AuthActivity for  GET_ORG_LIST_FAIL cases
                   * */

                    else ->{
                        onErrorReturn(GET_ORG_LIST_FAIL,false,false)
                    }

                }

            }

            override fun setJob(job: Job) {
                Log.d(TAG, "resetting repository job")
                repositoryJob?.cancel()
                repositoryJob = job
            }

        }.asLiveData()
    }


    //When refactoring code use NBR defined method onErrorReturn() instead of  OnCompleteJob(DataState.error())
    fun getLatestAppVersion(
        userAgent : String,
        isAppFirstRequest: Boolean
    ): LiveData<DataState<AuthViewState>>{

        return object : NetworkBoundResource<GetAppVersionResponse,AuthViewState>(nwChecker!!.isConnectedToTheInternet(),isAppFirstRequest){
            override fun createCall(): LiveData<GenericApiResponse<GetAppVersionResponse>> {
                if(isStaging){
                    Log.e(TAG, "getLatestAppVersion createCall() - SRID-STG")
                    return RetrofitBuilder.authApiService.getLatestAppVersion("SRID-STG",userAgent)
                }
               return RetrofitBuilder.authApiService.getLatestAppVersion(userAgent)
            }

            override suspend fun handleApiSuccessResponse(response: ApiSuccessResponse<GetAppVersionResponse>) {
                Log.d(TAG, "handleApiSuccessResponse: ${response}")
                when(response.body.code){
                    101 ->{
                        onCompleteJob(DataState.data(
                            data = AuthViewState(latestVersion = response.body.version),
                            response = null
                        ))
                    }
                    /* ErrorHandling
                   * --------------
                   *    User is shown the screen for "Server is not responding, Kindly try after sometime"
                   * */

                    else -> {
                        onErrorReturn(GET_LATEST_API_VERSION_FAIL,false,false)
                    }
                }
            }

            override fun setJob(job: Job) {
                Log.d(TAG, "resetting repository job")
                repositoryJob?.cancel()
                repositoryJob = job
            }

        }.asLiveData()
    }



    fun attemptSignIn(
      employeeID: String,
      password: String,
      orgName : String
    ): LiveData<DataState<AuthViewState>> {

        var org = orgName
        if(isStaging) org = org+"-STG"

        try {
            Integer.valueOf(employeeID)
        } catch ( e : NumberFormatException) {
            Log.e("AuthRepository","Precheck of employee id failed - not convertible to int!")
            return returnErrorResponse(CONVERSION_ERROR_SIGN_IN,ResponseType.Dialog())
        }

        return object : NetworkBoundResource<SignInResponse,AuthViewState>(nwChecker!!.isConnectedToTheInternet()){
            override fun createCall(): LiveData<GenericApiResponse<SignInResponse>> {
                return RetrofitBuilder.authApiService.signIn(
                    SessionManager.appStartDate,
                    org,
                    SignInObj(employeeID.toInt(),password)
                    )
            }

            override suspend fun handleApiSuccessResponse(response: ApiSuccessResponse<SignInResponse>) {
                Log.d(TAG, "handleApiSuccessResponse: ${response}")

                when (response.body.code) {
                    101 -> {
                        if(response.body.empDetails == null ){                                                                      //if emp details are null, just show server error
                            onErrorReturn(ErrorHandling.INTERNAL_SERVER_ERROR_MESSAGE,true,false)
                            return
                        }else{
                            onCompleteJob(
                                DataState.data(
                                    data = AuthViewState(
                                        registrationFields = null,
                                        healthStatus = response.body.healthStatus,
                                        empDetail = response.body.empDetails,
                                        time = response.body.time,
                                        authToken = AuthToken(response.header),
                                        resultMessage = response.body.message,
                                        resultMessageRedList = response.body.messageRedListUser
                                    ),
                                    response = null
                                )
                            )
                        }

                    }
                    /* ErrorHandling
                   * --------------
                   *    107 -> INTERNAL_SERVER_ERROR_MESSAGE dialog
                   *    102 -> Sign in failed, invalid username or password     (from server itself)
                   *    103 -> Sign in failed, user is not registered           (from server itself)
                   * */

                    107 -> {
                        onErrorReturn(ErrorHandling.INTERNAL_SERVER_ERROR_MESSAGE,true,false)
                    }

                    else -> {
                        onErrorReturn(response.body.description,true,false)
                    }
                }
            }

            override fun setJob(job: Job) {
                Log.d(TAG, "resetting repository job")
                repositoryJob?.cancel()
                repositoryJob = job
            }

        }.asLiveData()
    }

    fun attemptRegistration(
        employeeID: String,
        orgName : String,
        password: String
    ) : LiveData<DataState<AuthViewState>>{

        var org = orgName
        if(isStaging) org = org+"-STG"

        Log.e("AuthRepository","employee id = $employeeID and length = ${employeeID.length}")

        try {
            Integer.valueOf(employeeID)
        } catch ( e : NumberFormatException) {
            Log.e("AuthRepository","Precheck of employee id failed - not convertible to int!")
            return returnErrorResponse(CONVERSION_ERROR_REG,ResponseType.Dialog())
        }

        return object : NetworkBoundResource<RegistrationResponse,AuthViewState>(nwChecker!!.isConnectedToTheInternet()){
            override fun createCall(): LiveData<GenericApiResponse<RegistrationResponse>> {
                return RetrofitBuilder.authApiService.register(SessionManager.appStartDate,org,
                    RegistrationObj(
                        employeeID.toInt(),
                        orgName,
                        password
                    )
                )
            }

            override suspend fun handleApiSuccessResponse(response: ApiSuccessResponse<RegistrationResponse>) {
                Log.d("AuthRepository","handleApiSuccessResponse - response = $response")
                when(response.body.code){
                    101 -> {
                        onCompleteJob(DataState.data(
                            data = AuthViewState(
                                registrationFields = null,
                                healthStatus = null,
                                empDetail = response.body.empDetails,
                                time = null
                            ),
                            response = Response(Constants.REG_101_MESSAGE,ResponseType.Dialog())
                        ))
                    }

                    /* ErrorHandling
                     * --------------
                     *    107 -> INTERNAL_SERVER_ERROR_MESSAGE dialog
                     *    102 -> Registration failed, invalid employee id                   (from server itself)
                     *    103 -> Registration failed, employee already registered          (from server itself)
                     * */

                    107 -> {
                        onErrorReturn(ErrorHandling.INTERNAL_SERVER_ERROR_MESSAGE,true,false)
                    }

                    else -> {
                       onErrorReturn(response.body.description,true,false)
                    }
                }
            }

            override fun setJob(job: Job) {
                Log.d(TAG, "resetting repository job")
                repositoryJob?.cancel()
                repositoryJob = job
            }

        }.asLiveData()
    }

    fun updatePassword(
        employeeID: String,
        password: String,
        orgName: String
    ): LiveData<DataState<AuthViewState>> {
        var orgName = orgName

        if (isStaging) {
            orgName = orgName + "-STG"
        }

        try {
            Integer.valueOf(employeeID)
        } catch (e: NumberFormatException) {
            Log.e("AuthRepository", "Precheck of employee id failed - not convertible to int!")
            return returnErrorResponse(CONVERSION_ERROR_RESET_PWD, ResponseType.Dialog())
        }

        return object :
            NetworkBoundResource<UpdatePasswordResponse, AuthViewState>(nwChecker!!.isConnectedToTheInternet()) {
            override fun createCall(): LiveData<GenericApiResponse<UpdatePasswordResponse>> {
                Log.e(
                    "AuthRepository",
                    "sending request with parameters , orgname = $orgName , ondate = ${SessionManager.appStartDate}, InJsonBody = $employeeID , $password"
                )
                return RetrofitBuilder.authApiService.updatePassword(
                    orgName,
                    SessionManager.appStartDate,
                    SignInObj(employeeID.toInt(), password)
                )
            }

            override suspend fun handleApiSuccessResponse(response: ApiSuccessResponse<UpdatePasswordResponse>) {
                Log.e("AuthRepository", "handleApiSuccessResponse - response = $response")

                when (response.body.code) {

                    101 -> {
                        onCompleteJob(
                            DataState.data(
                                null,
                                Response(Constants.RESET_PASSWORD_101, ResponseType.Dialog())
                            )
                        )
                    }

                    102 -> {
                        onErrorReturn(ErrorHandling.RESET_PASSWORD_102,true,false)
                    }

                    107 -> {
                        onErrorReturn(ErrorHandling.INTERNAL_SERVER_ERROR_MESSAGE,true,false)
                    }

                    else -> {
                        onErrorReturn(response.body.description, true, false)
                    }

                }
            }

            override fun setJob(job: Job) {
                Log.d(TAG, "resetting repository job")
                repositoryJob?.cancel()
                repositoryJob = job
            }


        }.asLiveData()
    }


    //Use this if error in some fields BEFORE JOB to be started (no onComplete JOb in this)
    //Like checking if registration fields are right

    private fun returnErrorResponse(
        errorMessage: String,
        responseType: ResponseType
    ): LiveData<DataState<AuthViewState>> {
        Log.e("AuthRepository", "returnErrorResponse: ${errorMessage}")

        return object : LiveData<DataState<AuthViewState>>() {
            override fun onActive() {
                super.onActive()
                value = DataState.error(
                    Response(
                        errorMessage,
                        responseType
                    )
                )
            }
        }
    }

    fun cancelActiveJobs(){
        Log.d(TAG, "AuthRepository: Cancelling on-going jobs...")
        repositoryJob?.cancel()
    }
}