package com.samsung.covidsymptoms.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class RegistrationObj(
    @SerializedName("empid")
    @Expose
    var empID : Int,

    @SerializedName("orgname")
    @Expose
    var orgName : String,

    @SerializedName("password")
    @Expose
    var password : String

){
    override fun toString(): String {
        return "RegistrationObj(empID=$empID, orgName='$orgName', password='$password')"
    }
}