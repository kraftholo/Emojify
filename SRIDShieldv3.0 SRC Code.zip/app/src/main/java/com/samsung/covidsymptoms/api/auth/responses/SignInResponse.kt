package com.samsung.covidsymptoms.api.auth.responses

import com.samsung.covidsymptoms.models.EmpDetail
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class SignInResponse(

    @SerializedName("code")
    @Expose
    var code: Int,

    @SerializedName("description")
    @Expose
    var description: String,

    @SerializedName("healthstatus")
    @Expose
    var healthStatus: String,

    @SerializedName("empdetails")
    @Expose
    var empDetails: EmpDetail?,

    @SerializedName("time")
    @Expose
    var time: String,


    @SerializedName("message")
    @Expose
    var message: String,

    @SerializedName("message_for_red_list_user")
    @Expose
    var messageRedListUser: String

    ){
    override fun toString(): String {
        return "SignInResponse(code=$code, description='$description', healthStatus='$healthStatus', empDetails=$empDetails, time='$time', message='$message', messageRedListUser='$messageRedListUser')"
    }
}


