package com.samsung.covidsymptoms.worker

import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.SharedPreferences
import android.util.Log
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.samsung.covidsymptoms.session.SessionManager
import com.samsung.covidsymptoms.util.*

class AlarmNotificationWorker(context: Context, params: WorkerParameters) :
    Worker(context, params) {
    private val TAG = "AlarmNotificationWorker"
    private lateinit var preferences: SharedPreferences
    private var showNotification = false

    override fun doWork(): Result {
        val appContext = applicationContext
        return try {
            preferences = appContext.getSharedPreferences(Constants.PREFS_NAME, MODE_PRIVATE)
            val lastFilledDate = preferences.getString(Constants.KEY_DATE, "")

            if (!lastFilledDate.isNullOrEmpty()) {
                if (lastFilledDate != DateUtils.getCurrentDate()) showNotification = true
            } else {
                showNotification = true
            }

            val alarmManager = appContext.getSystemService(Context.ALARM_SERVICE) as AlarmManager?

            if (showNotification) {
                when (SessionManager.isInForeground) {
                    Constants.IN_FOREGROUND -> {
                        alarmManager?.setNextAlarm(appContext)
                        //show dialog here (for urgent)
                    }
                    Constants.IN_BACKGROUND -> {
                        //show notification here                         //app is in background
                        val notificationManager =
                            appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager?
                        notificationManager?.sendFillQuestionnaireNotification(
                            appContext
                        )
                    }
                    //null case (app not running)
                    else -> {
                        val notificationManager =
                            appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager?
                        notificationManager?.sendFillQuestionnaireNotification(
                            appContext
                        )
                    }
                }
            }
            //at 7 am even if notification wasnt shown .. alarm for next day should be scheduled
            alarmManager?.initializeAlarm(appContext)
            return Result.success()
        } catch (throwable: Throwable) {
            Log.e(TAG, "Error - $throwable")
            Result.failure()
        }
    }
}