package com.samsung.covidsymptoms.ui.main

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.*
import com.samsung.covidsymptoms.R
import com.samsung.covidsymptoms.models.Question
import com.samsung.covidsymptoms.util.Constants.Companion.CHECKBOX_TYPE
import com.samsung.covidsymptoms.util.Constants.Companion.COLOR_GREEN
import com.samsung.covidsymptoms.util.Constants.Companion.COLOR_RED
import com.samsung.covidsymptoms.util.Constants.Companion.EDITBOX_TYPE
import com.samsung.covidsymptoms.util.Constants.Companion.GROUP_TYPE
import com.samsung.covidsymptoms.util.Constants.Companion.HEADER_TYPE
import com.samsung.covidsymptoms.util.Constants.Companion.OTHER_TYPE
import com.samsung.covidsymptoms.util.Constants.Companion.SPINNER_PLUS_EDITBOX_TYPE
import com.samsung.covidsymptoms.util.Constants.Companion.SPINNER_TYPE
import kotlinx.android.synthetic.main.layout_checkbox_list_item.view.*
import kotlinx.android.synthetic.main.layout_checkbox_list_item.view.item_checkBox
import kotlinx.android.synthetic.main.layout_editbox_list_item.view.*
import kotlinx.android.synthetic.main.layout_othertype_list_item.view.*
import kotlinx.android.synthetic.main.layout_spinner_list_item.view.item_spinner
import kotlinx.android.synthetic.main.layout_spinner_list_item.view.item_spinnerTV
import kotlinx.android.synthetic.main.layout_spinner_with_editbox_child.view.*
import kotlinx.android.synthetic.main.layout_view_type_104.view.*
import kotlinx.coroutines.Dispatchers.Main
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap


class QuestionListAdapter(private val interaction: Interaction? = null) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object{
         var mLayoutManager : RecyclerView.LayoutManager? = null
         var questions = ArrayList<Question>()
         var mRecyclerView: RecyclerView? = null
         val mandatoryQuesList = ArrayList<Int>()                                               //filled at submitlist

         val dependencyMap = HashMap<Int,ArrayList<Int>>()                                      // hashmap of <question no , list of questions it's tick can influence>
         val questionMapper = HashMap<Int,Int>()                                                // hashmap to map questionno to list index
         val allDependencyLists = HashMap<Int,List<Int>>()                                    // all dependency lists in survey


        fun enableDisableOtherTypeHolderCardView(cv : CardView, enable: Boolean, questionToEnDis : Question){
            val otherQuesTV  =  cv.findViewById(R.id.item_otherQuesTitleTV) as TextView
            val otherQuesCheckBox = cv.findViewById(R.id.item_otherQuesTitleCheckBox) as CheckBox
            val furtherQuesTV = cv.findViewById(R.id.item_furtherQuesTV) as TextView
            val furtherQuesET = cv.findViewById(R.id.item_furtherQuesEditBox) as EditText

            otherQuesTV.isEnabled = enable
            otherQuesCheckBox.isEnabled = enable



            if(!enable){
                //UI change
                //DISABLE
                 otherQuesCheckBox.isChecked = false
                 furtherQuesET.setText("")
                 furtherQuesTV.isEnabled = false
                 furtherQuesET.isEnabled = false

                //Data change
                questionToEnDis.answer = "false"                                                                //reset the actual question too
                questionToEnDis.children[0].answer = ""

                questionMapper.get(questionToEnDis.questionNo)?.let { listPosition ->
                    Log.e("QuestionListAdapter","removing from mandatory list on disabling view!!! ")
                    mandatoryQuesList.removeAll(Collections.singleton(listPosition))
                }

            }
        }

        fun enableDisableViews(quesNo: Int, toEnable: Boolean) {
            Log.e("QuestionListAdapter","enableDisableViews() - quesNo = $quesNo , toenable = $toEnable")

            val influences = dependencyMap.get(quesNo)
            Log.e("QuestionListAdapter","enableDisableViews() - influences = $influences")
            influences?.let { influenceList ->
                for (quesNum: Int in influenceList) {
                    val listIndex = questionMapper.get(quesNum)
                    listIndex?.let { listPosition ->
                        val currDependencylist = allDependencyLists.get(quesNum)
                        if (!toEnable) {
                            //TO DISABLE

                            Log.e("QuestionListAdapter","enableDisableViews() - findViewByPosition = ${mLayoutManager?.findViewByPosition(listPosition)}")
                            //if even one from currDependency list is saying to disable -> disable view
                            if( mLayoutManager?.findViewByPosition(listPosition) != null ){
                                Log.e("QuestionListAdapter","enableDisableViews() - disabling question!")
                                val cv = mLayoutManager?.findViewByPosition(listPosition) as CardView
                                enableDisableOtherTypeHolderCardView(cv,false, questions[listPosition-1])
                            }else{
                                //next time when it shows, it should be disabled! (will be checked in its "bind" method)
                                Log.e("QuestionListAdapter","removing from mandatory list on disabling view!!! ")
                                mandatoryQuesList.removeAll(Collections.singleton(listPosition))

                                GlobalScope.launch(Main) {
                                    mRecyclerView?.adapter?.notifyItemChanged(listPosition) //incase out of screen and onbind already called
                                }
                            }

                        } else {
                            //to re-enable , check all in list                                      //eg: enable 142, so go in everyquestion in it's dependencyList
                            var flag = true
                            for(quesDL : Int in currDependencylist!!){
                                val question =  questions[questionMapper.get(quesDL)!!-1]

                                //TODO -> v imp here , questionMapper maps questionNo -> ROW IN LIST ,
                                // so for eg: questionMapper.get() -> 1 , it means 1st row of list (not 0th) and its corresponding ACTUAL question is at questions[0]!! not questions[1]

                                if(question.answer.equals("true",true))  flag = false           // some question in dependency list is ticked ,
                            }
                            if (flag) {
                                Log.e("QuestionListAdapter","enableDisableViews() - enabling question!")


                                if (mLayoutManager?.findViewByPosition(listPosition)!= null ){
                                    val cv = mLayoutManager?.findViewByPosition(listPosition) as CardView
                                    enableDisableOtherTypeHolderCardView(cv,true, questions[listPosition-1])
                                }
                                else{
                                    // next time when it shows, it should be enabled!
                                    GlobalScope.launch(Main) {
                                        mRecyclerView?.adapter?.notifyItemChanged(listPosition)
                                    }

                                    Log.e("QuestionListAdapter","enableDisableViews() - putting true for question no = $quesNum")
                                }
                            }else{
                                Log.e("QuestionListAdapter","enableDisableViews() - not all dependencies met  to enable!")
                            }
                        }
                    }
                }
            }

        }

    }

    val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Question>() {

        override fun areItemsTheSame(oldItem: Question, newItem: Question): Boolean {
            return oldItem.questionStr.equals(newItem.questionStr,true)
        }

        override fun areContentsTheSame(oldItem: Question, newItem: Question): Boolean {
            return oldItem == newItem
        }

    }
   private val differ =
        AsyncListDiffer(
            QuestionRecyclerChangeCallback(this),
            AsyncDifferConfig.Builder(DIFF_CALLBACK).build()
        )

    internal inner class QuestionRecyclerChangeCallback(
        private val adapter: QuestionListAdapter
    ) : ListUpdateCallback {

        override fun onChanged(position: Int, count: Int, payload: Any?) {
            adapter.notifyItemRangeChanged(position, count, payload)
        }

        override fun onInserted(position: Int, count: Int) {
            adapter.notifyItemRangeChanged(position, count)
        }

        override fun onMoved(fromPosition: Int, toPosition: Int) {
            adapter.notifyDataSetChanged()
        }

        override fun onRemoved(position: Int, count: Int) {
            adapter.notifyDataSetChanged()
        }
    }


    override fun getItemViewType(position: Int): Int {

        if(position == 0) return HEADER_TYPE

        // for Difference in checkBoxTypeHOlder and  OtherViewTypeHOlder
        if(differ.currentList[position-1].viewType == 101){
            //hard coding here
            if(differ.currentList[position-1].hasChildren){
                return OTHER_TYPE
            }
        }

        if(differ.currentList[position-1].viewType == 103){
            //hard coding here
            if(differ.currentList[position-1].hasChildren){
                return SPINNER_PLUS_EDITBOX_TYPE
            }
        }
        Log.d("QuestionListAdapter","getItemViewType() - ${differ.currentList[position-1].viewType} returned")
        return differ.currentList[position-1].viewType
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        when(viewType){

            HEADER_TYPE -> {
                return HeaderTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_recycler_view_header,
                        parent,
                        false
                    ),
                    interaction
                )

            }

            //101
            CHECKBOX_TYPE -> {
                return CheckBoxTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_checkbox_list_item,
                        parent,
                        false
                    ),
                    interaction
                )
            }

            //102
            EDITBOX_TYPE -> {
                return EditBoxTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_editbox_list_item,
                        parent,
                        false
                    ),
                    interaction
                )
            }

            //103
            SPINNER_TYPE ->{
                return SpinnerTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_spinner_list_item,
                        parent,
                        false
                    ),
                    interaction
                )
            }

            //104 (symptoms type)
            GROUP_TYPE ->{
                return GroupTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_view_type_104,
                        parent,
                        false
                    ),
                    interaction
                )
            }

            //105   (checkbox + editbox type)
            OTHER_TYPE ->{
                return OtherTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_othertype_list_item,
                        parent,
                        false
                    ),
                    interaction
                )
            }

            //106 (spinner + editbox)
            SPINNER_PLUS_EDITBOX_TYPE -> {
                return SpinnerPlusEditboxHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_spinner_with_editbox_child,
                        parent,
                        false
                    ),
                    interaction
                )
            }


            //not going to happen
            else ->{
                return CheckBoxTypeHolder(
                    LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_checkbox_list_item,
                        parent,
                        false
                    ),
                    interaction
                )
            }

        }

    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is CheckBoxTypeHolder -> {
                holder.bind(differ.currentList[position-1],position)
            }
            is EditBoxTypeHolder -> {
                holder.bind(differ.currentList[position-1],position)
            }

            is SpinnerTypeHolder -> {
                holder.bind(differ.currentList[position-1],position)
            }

            is GroupTypeHolder -> {
                holder.bind(differ.currentList[position-1],position)
            }

            is OtherTypeHolder -> {
                holder.bind(differ.currentList[position-1],position)
            }

            is SpinnerPlusEditboxHolder -> {
                holder.bind(differ.currentList[position-1],position)
            }

            is HeaderTypeHolder ->{
                //Nothing to bind
            }
        }
    }

    override fun getItemCount(): Int {
        return differ.currentList.size + 1              //+1 since header is extra at top
    }

    fun submitList(list: List<Question>) {
        questions.clear()
        questions.addAll(list)

        //fill up maps and other stuff at start itself

        for( (position,currQues) in list.withIndex() ){
            if(currQues.isMandatory == 1) mandatoryQuesList.add(position+1)            //eg: Q-1 is mandatory, so mandatorylist will add 1 and not 0

            questionMapper.put(currQues.questionNo,position+1)                                        //questionNo mapped to index in list

            val questionDependencyList = currQues.dependencyList              //eg. say for quesno 142 , dependencyList is <132,121>
            if(questionDependencyList!=null && questionDependencyList.size != 0){
                Log.e("QuestionListAdapter",
                    "submitList() - questionDependencyList is not empty , $questionDependencyList")
                allDependencyLists.put(currQues.questionNo, questionDependencyList)                 //store dependency list

                for(quesNo : Int in questionDependencyList){
                    var influences  = dependencyMap.get(quesNo)                                     // list of all questions influenced by question no 132
                    if(influences!=null){
                        if(!influences.contains(currQues.questionNo)) influences.add(currQues.questionNo)
                        // add current question to list
                    }else{
                        influences = arrayListOf(currQues.questionNo)
                    }
                    dependencyMap.put(quesNo,influences)                                            //update the map
                }
            }
        }
        differ.submitList(list)
    }



    class HeaderTypeHolder
    constructor(
        itemView: View,
        private val interaction: Interaction?
    ) : RecyclerView.ViewHolder(itemView) {
    }

    class CheckBoxTypeHolder                                                        //answer used is boolean
    constructor(
        itemView: View,
        private val interaction: Interaction?
    ) : RecyclerView.ViewHolder(itemView) {

        fun bind(ques: Question, listPosition : Int) = with(itemView) {
            itemView.setOnClickListener {
                interaction?.onItemSelected(adapterPosition, ques)
            }


            if(ques.isMandatory==1) mandatoryQuesList.add(listPosition)                      //by default added

            item_checkBoxTV.text = if(ques.isMandatory==1) {
                "Q-${listPosition}  ${ques.questionStr} *"
            }else{
                "Q-${listPosition}  ${ques.questionStr}"
            }

            //coming from server or when scrolled and called again
            if(ques.answer.equals("true",true)){
                item_checkBox.isChecked = true
                if(ques.isMandatory==1) mandatoryQuesList.removeAll(Collections.singleton(listPosition))
            }
            else if(ques.answer.equals("false",true)){
                item_checkBox.isChecked = false
            }
            else{
                item_checkBox.isChecked = false
                ques.answer = "false"                   //if empty comes from server, preset the answer to send as false
            }

            //updating the question if user clicks checkbox of a PARENT
            item_checkBox.setOnClickListener{
                Log.d("QuestionListAdapter","CheckBoxTypeHolder onClick of  Question called")
                ques.answer = item_checkBox.isChecked.toString()
                if(item_checkBox.isChecked){
                    if(ques.isMandatory==1) mandatoryQuesList.removeAll(Collections.singleton(listPosition))

                    if (dependencyMap.containsKey(ques.questionNo)) {
                        Log.e("QuestionListAdapter","Checkboxtype question : Exists in someone's dependency list and is checked!")
                        enableDisableViews(ques.questionNo,false)
                    }

                }else{
                    if(ques.isMandatory==1) mandatoryQuesList.add(listPosition)
                    if (dependencyMap.containsKey(ques.questionNo)) {
                        Log.e("QuestionListAdapter","Checkboxtype question : Exists in someone's dependency list and is checked!")
                        enableDisableViews(ques.questionNo,true)
                    }
                }
            }
        }

    }


    class EditBoxTypeHolder                                                                 //answer used is String
    constructor(
        itemView: View,
        private val interaction: Interaction?
    ) : RecyclerView.ViewHolder(itemView) {

        fun bind(ques: Question,listPosition : Int) = with(itemView) {
            itemView.setOnClickListener {
                interaction?.onItemSelected(adapterPosition, ques)
            }
            item_editBoxTV.text = if(ques.isMandatory==1) {
                "Q-${listPosition}  ${ques.questionStr} *"
            }else{
                "Q-${listPosition}  ${ques.questionStr}"
            }
            item_editTextBox.setText(ques.answer)

            if(ques.isMandatory==1){
                if(ques.answer != "") mandatoryQuesList.add(listPosition)
            }
            //updating the list

            item_editBoxTV.setOnFocusChangeListener { v, hasFocus ->
                if(!hasFocus) {
                    val answerToSend = (v as EditText).text.toString().replace("'","\\'")
                    ques.answer  = answerToSend

                    if(ques.isMandatory==1){
                        if(!answerToSend.isBlank()){
                            mandatoryQuesList.removeAll(Collections.singleton(listPosition))
                        }else{
                            mandatoryQuesList.add(listPosition)
                        }
                    }
                    Log.d("QuestionListAdapter","EditBoxTypeHolder saving furtherQuesEditBoxAns ${ques.answer}  ")
                }
            }
        }
    }

    class SpinnerTypeHolder                                                   //answer used is Int 0/1/2
    constructor(
        itemView: View,
        private val interaction: Interaction?
    ) : RecyclerView.ViewHolder(itemView) {

        fun bind(ques: Question,listPosition : Int) = with(itemView) {
            itemView.setOnClickListener {
                interaction?.onItemSelected(adapterPosition, ques)
            }

            val spinnerList = ArrayList<String>()
            spinnerList.addAll(ques.spinnerStr)
            spinnerList.add(0,"Select Preference")

           mandatoryQuesList.add(listPosition)

            Log.e("QuestionListAdapter","SpinnerTypeHolder - spinnerStr list - ${spinnerList}")

            val mAdapter = MySpinnerAdapter(context,R.layout.layout_spinner_option_row,spinnerList)
            item_spinner.adapter = mAdapter

            Log.e("QuestionListAdapter","SpinnerTypeHolder - ques.answer =  ${ques.answer}")
            if(ques.answer!=""){
                Log.e("QuestionListAdapter","SpinnerTypeHolder - default selection  =  ${ques.answer.toInt()}")
                item_spinner.setSelection(ques.answer.toInt()+1)
                mandatoryQuesList.removeAll(Collections.singleton(listPosition))
            }


            item_spinnerTV.setText("Q-${listPosition}  ${ques.questionStr} *")

            //updating question according to option chosen
            item_spinner?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
                override fun onNothingSelected(parent: AdapterView<*>?) {
                }

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    if(position!= 0 ){
                        Log.e("QuestionListAdapter","SpinnerTypeHolder saving selected value  - ${position-1}")
                        ques.answer = (position-1).toString()
                        mandatoryQuesList.removeAll(Collections.singleton(listPosition))
                    }
                }

            }
        }
    }


    class OtherTypeHolder
    constructor(
        itemView: View,
        private val interaction: Interaction?
    ) : RecyclerView.ViewHolder(itemView) {


        fun bind(ques: Question,listPosition : Int) = with(itemView) {
            itemView.setOnClickListener {
                interaction?.onItemSelected(adapterPosition, ques)
            }

            Log.e("QuestionListAdapter","bind of OtherTypeHolder called for listposition = $listPosition")

            item_otherQuesTitleTV.text = if(ques.isMandatory==1) {
                "Q-${listPosition}  ${ques.questionStr} *"
            }else{
                "Q-${listPosition}  ${ques.questionStr}"
            }

            item_furtherQuesTV.setText(ques.children[0].questionStr)


            //on bind check dependency list yourself
            var flag = true                                                             //for checkbox+editbox with no dependent list, this will always be true
            val dependencyList = ques.dependencyList
            if(dependencyList != null && dependencyList.isNotEmpty()){
                Log.e("QuestionListAdapter","OtherTypeHolder - dependency list = $dependencyList")
                //this is a dependency question
                for(dependencyQues : Int in dependencyList){
                    val question =  questions[questionMapper.get(dependencyQues)!!-1]
                    Log.e("QuestionListAdapter","OtherTypeHolder - checking answer of question no. = ${question.questionNo} and its ques.answer = ${question.answer}")
                    if(question.answer.equals("true",true)){
                        flag = false
                        break
                    }           // some question in dependency list is ticked ,
                }
                if(flag){
                    Log.e("QuestionListAdapter","bind() of otherViewHolder - enabling question! (default case)")
                    enableDisableOtherTypeHolderCardView(itemView as CardView, true,ques)
                }else{
                    Log.e("QuestionListAdapter","bind()  of otherViewHolder - disabling question! (state saved previously)")
                    enableDisableOtherTypeHolderCardView(itemView as CardView,false,ques)
                }
            }

            if(flag){                                                                                   // if it is decided to be enabled then put server values
                //coming from server
                if(ques.answer.equals("true",true)){
                    mandatoryQuesList.add(listPosition)                                                 //if ticked,has to be filled
                    item_otherQuesTitleCheckBox.isChecked = true
                    item_furtherQuesEditBox.isEnabled = true
                    item_furtherQuesTV.isEnabled = true
                    item_furtherQuesEditBox.setText( ques.children[0].answer)
                }
                else if(ques.answer.equals("false",true)){
                    item_otherQuesTitleCheckBox.isChecked = false
                }
                else{
                    item_otherQuesTitleCheckBox.isChecked = false
                    ques.answer = "false"                   //if empty comes from server, preset the answer to send as false
                }

                if(item_furtherQuesEditBox.isEnabled){
                    if(item_furtherQuesEditBox.text.toString().isBlank()){
                        mandatoryQuesList.add(listPosition)                     //if ticked and not filled
                    }else{
                        mandatoryQuesList.removeAll(Collections.singleton(listPosition))
                    }
                }
            }

            item_otherQuesTitleCheckBox.setOnClickListener {v ->
                Log.d("QuestionListAdapter","OtherTypeHolder checkBox was clicked ")
                if((v as CheckBox).isChecked){
                    Log.d("QuestionListAdapter","OtherTypeHolder enabling furtherQues ")
                    ques.answer = "true"
                    item_furtherQuesEditBox.isEnabled = true
                    item_furtherQuesTV.isEnabled = true

                    if (dependencyMap.containsKey(ques.questionNo)) {
                        Log.e("QuestionListAdapter","Checkboxtype question : Exists in someone's dependency list and is checked!")
                        enableDisableViews(ques.questionNo,false)
                    }

                    mandatoryQuesList.add(listPosition)

                }else{
                    mandatoryQuesList.removeAll(Collections.singleton(listPosition))
                    Log.d("QuestionListAdapter","OtherTypeHolder disabling furtherQues ")
                    item_furtherQuesEditBox.setText("")
                    ques.answer = "false"
                    ques.children[0].answer = ""
                    item_furtherQuesEditBox.isEnabled = false
                    item_furtherQuesTV.isEnabled = false

                    if (dependencyMap.containsKey(ques.questionNo)) {
                        Log.e("QuestionListAdapter","Checkboxtype question : Exists in someone's dependency list and is checked!")
                        enableDisableViews(ques.questionNo,true)
                    }
                }

            }

            //updating answer
            item_furtherQuesEditBox.setOnFocusChangeListener( object : View.OnFocusChangeListener{
                override fun onFocusChange(v: View?, hasFocus: Boolean) {
                    if(!hasFocus) {
                        val answerToSend = (v as EditText).text.toString().replace("'","\\'")
                        ques.children[0].answer  = answerToSend
                        Log.d("QuestionListAdapter","OtherTypeHolder saving furtherQuesEditBoxAns - ${ ques.children[0].answer } ")
                        if(!answerToSend.isBlank())  mandatoryQuesList.removeAll(Collections.singleton(listPosition))
                    }
                }
            })

        }
    }

    class GroupTypeHolder
    constructor(
        itemView: View,
        private val interaction: Interaction?
    ) : RecyclerView.ViewHolder(itemView) {


        //called when deselecting a symptom or editbox text to ""
        private fun turnQues_AnswerToFalse(listPosition: Int) {
            val question = questions[listPosition - 1]

            var flag = false
            for ((index, child) in question.children.withIndex()) {

                Log.e("QuestionListAdapter","turnQues_AnswerToFalse() - subquestion $index has answer = ${child.answer}")

                if (index == 5) { //none of the above case
                    if(question.children[5].answer == "true"){  // will reach here when no symptom is selected , now if NOTA is SELECTED, REMOVE from mandatory list (because we add in every false case)
                        mandatoryQuesList.removeAll(Collections.singleton(listPosition))
                    }
                    continue
                } else {
                    if (child.answer.equals("true", true)) {
                        mandatoryQuesList.removeAll(Collections.singleton(listPosition))
                        flag = true
                        break
                    }
                }
            }
            if (!flag) {  //(flag unchanged)
                //no checkbox ticked
                Log.e("QuestionListAdapter","GroupTypeHolder - setting question no. ${question.questionNo} to FALSE in questions list!")
                question.answer = "false"
                enableDisableViews(
                    question.questionNo,
                    true
                )        //then only try to disable the view it influences
            } else {
                Log.e("QuestionListAdapter","GroupTypeHolder - unticked but some other symptom is selected!, parent question answer still remains TRUE !!")
            }

        }

        fun bind(ques: Question, listPosition: Int) = with(itemView) {
            itemView.setOnClickListener {
                interaction?.onItemSelected(adapterPosition, ques)
            }

            if (ques.isMandatory == 1) {
                var flag = true
                for (element in ques.children) {
                    if (element.answer != "") {          //it is filled
                        flag = false
                        break
                    }
                }
                if (flag) {
                    mandatoryQuesList.add(listPosition)
                } else {
                    mandatoryQuesList.removeAll(Collections.singleton(listPosition))
                }
            }

            group_question_title.text = if (ques.isMandatory == 1) {
                "Q-${listPosition}  ${ques.questionStr} *"
            } else {
                "Q-${listPosition}  ${ques.questionStr}"
            }

            //hardcode!!
            val idsOfChildren = ArrayList<Int>()
            idsOfChildren.add(R.id.item_checkBox_1)
            idsOfChildren.add(R.id.item_checkBox_2)
            idsOfChildren.add(R.id.item_checkBox_3)
            idsOfChildren.add(R.id.item_checkBox_4)
            idsOfChildren.add(R.id.item_checkBox_5)
            idsOfChildren.add(R.id.item_checkBox_6)

            val idsOfCheckBoxTVs = ArrayList<Int>()
            idsOfCheckBoxTVs.add(R.id.item_checkBoxTV_1)
            idsOfCheckBoxTVs.add(R.id.item_checkBoxTV_2)
            idsOfCheckBoxTVs.add(R.id.item_checkBoxTV_3)
            idsOfCheckBoxTVs.add(R.id.item_checkBoxTV_4)
            idsOfCheckBoxTVs.add(R.id.item_checkBoxTV_5)
            idsOfCheckBoxTVs.add(R.id.item_checkBoxTV_6)

            //onbind when called and checkboxes are checked in value but not in UI (due to server or scrolling)
            for ((index, childViewId) in idsOfChildren.withIndex()) {
                    val childCheckBox = itemView.findViewById<CheckBox>(childViewId)
                    childCheckBox.isChecked = when (ques.children[index].answer) {
                        "true" -> true
                        "false" -> false
                        else -> {
                            ques.children[index].answer = "false"
                            false
                        }
                    }
            }

            //setting on click listeners
            for ((index, childViewId) in idsOfChildren.withIndex()) {
              if (index == 5) {
                    val noneOfTheAboveCB = itemView.findViewById<CheckBox>(childViewId)
                    val noneOfTheAboveTV = itemView.findViewById<TextView>(idsOfCheckBoxTVs[index])
                    noneOfTheAboveTV.setText(ques.children[index].questionStr)

                  noneOfTheAboveCB.setOnClickListener {
                      if(noneOfTheAboveCB.isChecked){
                          if (ques.isMandatory == 1) mandatoryQuesList.removeAll(
                              Collections.singleton(
                                  listPosition
                              )
                          )
                          ques.answer = "false"
                          ques.children[index].answer = "true"

                      }else{
                          if (ques.isMandatory == 1) mandatoryQuesList.add(listPosition)
                          ques.children[index].answer = "false"
                      }

                      //ui change
                      item_checkBox_1.isChecked = false
                      item_checkBox_2.isChecked = false
                      item_checkBox_3.isChecked = false
                      item_checkBox_4.isChecked = false
                      item_checkBox_5.isChecked = false                //editbox reset

                      //data change
                      ques.children[0].answer = "false"
                      ques.children[1].answer = "false"
                      ques.children[2].answer = "false"
                      ques.children[3].answer = "false"
                      ques.children[4].answer = "false"

                      enableDisableViews(ques.questionNo, true)
                  }

                } else {
                    val childCheckBox = itemView.findViewById<CheckBox>(childViewId)
                    val childCheckBoxTV = itemView.findViewById<TextView>(idsOfCheckBoxTVs[index])
                    childCheckBoxTV.setText(ques.children[index].questionStr)

                    childCheckBox.setOnClickListener {
                        if(childCheckBox.isChecked){
                            if (ques.isMandatory == 1) mandatoryQuesList.removeAll(
                                Collections.singleton(
                                    listPosition
                                )
                            )

                            Log.e("QuestionListAdapter","GroupTypeHolder - setting question no. ${ques.questionNo}'s ques.answer to TRUE in questions list!")
                            ques.answer = "true"
                            ques.children[index].answer = "true"
                            enableDisableViews(ques.questionNo,false)

                        }else{
                            if (ques.isMandatory == 1) mandatoryQuesList.add(listPosition)
                            //this symptom disable but (NOTA selected or some other symptom selected) ,then no need to add in list, this will be reconsidered in turnQues_AnswerToFalse()
                            ques.children[index].answer = "false"
                            turnQues_AnswerToFalse(listPosition)
                        }

                        //NOTA change
                        item_checkBox_6.isChecked = false               //ui change
                        ques.children[5].answer = "false"               //data change
                    }
                }
            }

        }
    }

    class SpinnerPlusEditboxHolder
    constructor(
        itemView: View,
        private val interaction: Interaction?
    ) : RecyclerView.ViewHolder(itemView) {

        fun bind(ques: Question,listPosition : Int) = with(itemView) {
            itemView.setOnClickListener {
                interaction?.onItemSelected(adapterPosition, ques)
            }

            if(ques.isMandatory==1) mandatoryQuesList.add(listPosition)

            val spinnerList = ArrayList<String>()
            spinnerList.addAll(ques.spinnerStr)
            spinnerList.add(0,"Select Locality")


            Log.e("QuestionListAdapter","SpinnerPlusEditboxHolder - spinnerStr list - ${spinnerList}")

            val mAdapter = MySpinnerAdapter(context,R.layout.layout_spinner_option_row,spinnerList)
            spinner.adapter = mAdapter

            spinnerTV.setText("Q-${listPosition}  ${ques.questionStr}")

            //updating question according to option chosen
            spinner?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
                override fun onNothingSelected(parent: AdapterView<*>?) {
                }
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    Log.e("QuestionListAdapter","SpinnerPlusEditboxHolder saving selected value  - ${position-1}")
                    ques.answer = (position-1).toString()
                    if(ques.isMandatory==1) mandatoryQuesList.removeAll(Collections.singleton(listPosition))
                    val selectedVal = parent?.getItemAtPosition(position) as String

                    selectedVal.let {
                        if(it.equals("Others",true)) {
                            othersET.isEnabled = true
                            othersET.hint = "Please enter your locality"
                        }else{
                            othersET.isEnabled = false
                            othersET.hint = ""
                            othersET.setText("")
                        }
                    }
                }
            }

            //TODO- check if this works,because should be focusable when it is actually enabled

            othersET.setOnFocusChangeListener( object : View.OnFocusChangeListener{
                override fun onFocusChange(v: View?, hasFocus: Boolean) {
                    if(!hasFocus) {
                        val answerToSend = (v as EditText).text.toString().replace("'","\\'")
                        ques.answer  = answerToSend
                        ques.children[0].answer  = answerToSend
                        Log.d("QuestionListAdapter","SpinnerPlusEditboxHolder saving others location - ${ ques.children[0].answer } ")
                    }
                }

            })


        }
    }


    private fun updateStatus(currStatus : String , quesImpact : String ) : String{
        var retVal = ""
        if(currStatus.equals(COLOR_RED,true)){
            retVal = currStatus
        }

        if(currStatus.equals(COLOR_GREEN,true)) {
            if(quesImpact.equals("none",true)){
                retVal = currStatus
            }else{
                retVal = quesImpact
            }
        }

        return retVal
    }

    //will return a color other than green,red iff =>  Inside loop and currentHealthStatus = green , some question's impactOnStatus = "example"
    // then, this function will return "example"/ "" as color

    fun calculateHealthStatus(): String{
        var currentHealthStatus = COLOR_GREEN
        for( parentQuestion:Question in differ.currentList ){
            if(currentHealthStatus.equals(COLOR_RED,true)) break

            //currentHealthStatus is green
            when(parentQuestion.viewType){
                CHECKBOX_TYPE ->{
                    if(parentQuestion.answer.equals("true",true)) {
                        Log.d(
                            "QuestionAdapter",
                            "Health Status updated to  -${parentQuestion.impactOnStatus} from $currentHealthStatus"
                        )
                        currentHealthStatus = updateStatus(currentHealthStatus, parentQuestion.impactOnStatus)
                    }
                }

                GROUP_TYPE -> {
                    val childQuestions = parentQuestion.children

                    if(childQuestions[childQuestions.size-1].answer.equals("true",true) ){
                        //if none of the above is checked ::Assumption -> it is the last item in childQuestions list
                        Log.d("QuestionAdapter","None of the above was  checked")
                    }

                    //editbox other symptom hardcode
                    else if(!childQuestions[childQuestions.size-2].answer.equals("")){      // edit box is filled up
                        Log.d("QuestionAdapter","Editbox was filled up!")
                        currentHealthStatus = updateStatus(currentHealthStatus,childQuestions[childQuestions.size-2].impactOnStatus)
                    }

                    else{
                        for( childQuestion in childQuestions){
                            if(childQuestion.answer.equals("true",true) ){
                                //do not check futher if red also, i need to check if atleast one of the child here is enabled
                                Log.d("QuestionAdapter","Health Status updated to  -${childQuestion.impactOnStatus}from $currentHealthStatus")
                                currentHealthStatus = updateStatus(currentHealthStatus,childQuestion.impactOnStatus)
                                if(currentHealthStatus.equals(COLOR_RED,true)) break
                            }
                        }
                    }
                }

                OTHER_TYPE -> {
                    if(parentQuestion.answer.equals("true",true) ) {
                        Log.d(
                            "QuestionAdapter",
                            "Health Status updated to  -${parentQuestion.impactOnStatus} from $currentHealthStatus"
                        )
                        currentHealthStatus = updateStatus(currentHealthStatus, parentQuestion.impactOnStatus)
                    }
                }
                else -> {
                    //no contribution in score
                }
            }
        }
        return currentHealthStatus.toLowerCase().trim()                         //possible return values - "red","green"
    }

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        mLayoutManager = recyclerView.layoutManager
        mRecyclerView = recyclerView
    }


    interface Interaction {
        fun onItemSelected(position: Int, item: Question)
    }
}

