package com.example.covidsymptoms.util

import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.covidsymptoms.R
import com.example.covidsymptoms.receiver.ActivityDecider
import com.example.covidsymptoms.ui.auth.AuthActivity
import com.example.covidsymptoms.ui.main.MainActivity

// Notification ID.
private val NOTIFICATION_ID = 0
private val REQUEST_CODE = 0
private val FLAGS = 0
private val TAG = "NotificationUtils"

fun NotificationManager.sendFillQuestionnaireNotification(context : Context){
            Log.e(TAG,"sendFillQuestionnaireNotification()")
            val builder = NotificationCompat.Builder(context,Constants.CHANNEL_ID)
            val contentIntent = Intent(context,ActivityDecider::class.java)
            val contentPendingIntent = PendingIntent.getBroadcast(
                    context,
                    REQUEST_CODE,
                    contentIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT
            )
            builder
                .setSmallIcon(R.mipmap.ic_app_icon)
                .setContentTitle(context.resources.getString(R.string.notification_title))
                .setContentIntent(contentPendingIntent)
                .setAutoCancel(true)
                .setStyle(NotificationCompat.BigTextStyle().bigText(context.resources.getString(R.string.notification_message_body)))
                .setPriority(NotificationCompat.PRIORITY_HIGH)

            notify(NOTIFICATION_ID,builder.build())

            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager?
            alarmManager?.setNextAlarm(context)

}




