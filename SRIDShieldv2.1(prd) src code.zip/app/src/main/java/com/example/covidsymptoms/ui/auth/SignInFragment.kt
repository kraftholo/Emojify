package com.example.covidsymptoms.ui.auth

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import com.example.covidsymptoms.R
import com.example.covidsymptoms.encyption.CipherWrapper
import com.example.covidsymptoms.encyption.KeyStoreWrapper
import com.example.covidsymptoms.models.Organisation
import com.example.covidsymptoms.session.SessionManager
import com.example.covidsymptoms.ui.auth.adapter.OrganizationSpinnerAdapter
import com.example.covidsymptoms.ui.auth.state.AuthStateEvent
import com.example.covidsymptoms.ui.auth.state.SignInFields
import com.example.covidsymptoms.ui.displayErrorDialog
import com.example.covidsymptoms.util.Constants
import com.example.covidsymptoms.util.DateUtils
import kotlinx.android.synthetic.main.fragment_signin.*
import java.lang.Exception

//Now this fragment is not used!!
class SignInFragment : Fragment() {

    val TAG = "SignInFragment"

    //---------------used for encryption/decryption-----------------------
    private var autofillEnabled = false
    private lateinit var keyStoreWrapper : KeyStoreWrapper
    private var cipherWrapper = CipherWrapper(CipherWrapper.TRANSFORMATION_ASYMMETRIC)
    private lateinit var sharedPreferences : SharedPreferences
    //--------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        keyStoreWrapper = KeyStoreWrapper(context!!)
        sharedPreferences = context!!.getSharedPreferences(Constants.PREFS_NAME,Context.MODE_PRIVATE)
        //autofill enabled for only API 18+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) autofillEnabled = true

        val viewModel: AuthViewModel by activityViewModels()
        Log.d(TAG, "Viewmodel - ${viewModel.hashCode()}")
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_signin, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //fire off sign in network request
        if (autofillEnabled) {
            initViews()
        } else {
            initSpinner(null)
        }

        signInButton.setOnClickListener {
            signIn()
        }
        resetPasswordTV.setOnClickListener {
            findNavController().navigate(R.id.action_signInFragment_to_resetPasswordFragment)
        }
    }

    private fun initSpinner(savedOrgName : String?) {
        val viewModel: AuthViewModel by activityViewModels()
        val orgListInViewModel = viewModel.getCurrentViewStateOrNew().orgListReceived
        val spinnerList = ArrayList<String>()
        var positionForSavedOrg = 0

        //good way to access value and index in for loop
        for((index,org) in orgListInViewModel!!.withIndex()){
            savedOrgName?.let {
                if(org.orgName.equals(it,true)) positionForSavedOrg = index
            }
            spinnerList.add(org.orgName)
        }

        Log.e(TAG, "spinnerlist is $spinnerList")

        activity?.let {
            val mAdapter =
                OrganizationSpinnerAdapter(it, R.layout.layout_org_spinner_option_row, spinnerList)
            orgSpinner.adapter = mAdapter
            orgSpinner.setSelection(positionForSavedOrg)                                            //if previousSavedOrg is found somewhere, positionForSavedOrg!=0 else it'll be 0
        }
    }

    private fun signIn() {
        val vm: AuthViewModel by activityViewModels()

        val signInFieldErrors = SignInFields(
            input_empID.text.toString(),
            input_password.text.toString()
        ).isValidForSignIn()

        if (signInFieldErrors != SignInFields.SignInError.none()) {
            context!!.displayErrorDialog(signInFieldErrors)
        } else {
            SessionManager.appStartDate = DateUtils.getCurrentDate()                //update the date before login
            if (autofillEnabled) updateUserDetailsInSharedPref()
            vm.setStateEvent(
                AuthStateEvent.SignInAttemptEvent(
                    input_empID.text.toString(),
                    input_password.text.toString(),
                    orgSpinner.selectedItem as String
                )
            )
        }
    }

    //18+
    private fun updateUserDetailsInSharedPref() {
        val editor = sharedPreferences.edit()
        val masterKey = keyStoreWrapper.getAndroidKeyStoreAsymmetricKeyPair(Constants.MASTER_KEY)

        try {
            //encryption by public key
            val encrypted_empID = cipherWrapper.encrypt(input_empID.text.toString(),masterKey?.public)
            val encrypted_pwd = cipherWrapper.encrypt(input_password.text.toString(),masterKey?.public)
            val encrypted_orgName = cipherWrapper.encrypt(orgSpinner.selectedItem.toString(),masterKey?.public)

            Log.e(TAG,"updateUserDetailsInSharedPref() - empId = $encrypted_empID")

            editor.putString(Constants.KEY_EMPID,encrypted_empID)
            editor.putString(Constants.KEY_PASSWORD,encrypted_pwd)
            editor.putString(Constants.KEY_ORGNAME,encrypted_orgName)
            editor.apply()
        }catch (e : Exception){
            Log.e(TAG,"updateUserDetailsInSharedPref() - error while encrypting = $e")
            //nothing to update in shared pref
        }
    }

    //18+
    private fun initViews() {
        val masterKey = keyStoreWrapper.getAndroidKeyStoreAsymmetricKeyPair(Constants.MASTER_KEY)
        //getting encrypted data from sharedPref
        val savedEmpID = sharedPreferences.getString(Constants.KEY_EMPID,null)
        val savedPwd = sharedPreferences.getString(Constants.KEY_PASSWORD,null)
        val savedOrgName = sharedPreferences.getString(Constants.KEY_ORGNAME,null)

        try {
            //decryption by private key
            val decrypted_empID = savedEmpID?.let {
                cipherWrapper.decrypt(it, masterKey?.private)
            } ?: ""

            val decrypted_pwd = savedPwd?.let {
                cipherWrapper.decrypt(it,masterKey?.private)
            } ?: ""

            val decrypted_orgName = savedOrgName?.let {
                cipherWrapper.decrypt(it,masterKey?.private)
            }

            Log.e(TAG,"initViews() - empId = $decrypted_empID, password= $decrypted_pwd, orgName = $decrypted_orgName ")

            input_empID.setText(decrypted_empID)
            input_password.setText(decrypted_pwd)
            initSpinner(decrypted_orgName)             // no else case as null handled in initSpinner()

        }catch (e : Exception){
            Log.e(TAG,"initViews() - error while decrypting = $e")
            //nothing to set to employeeid and password
            initSpinner(null)
        }
    }

}
