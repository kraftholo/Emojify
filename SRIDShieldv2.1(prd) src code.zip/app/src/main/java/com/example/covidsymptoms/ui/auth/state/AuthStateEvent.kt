package com.example.covidsymptoms.ui.auth.state

sealed class AuthStateEvent{

    data class SignInAttemptEvent(
        val employeeID : String,
        val password : String,
        val orgName : String
    ) : AuthStateEvent()

    data class RegisterAttemptEvent(
        val employeeID: String,
        val orgName : String,
        val password : String
    ): AuthStateEvent()

    data class GetLatestAppVersion(
        val userAgent : String,
        val isAppFirstRequest: Boolean
    ) :AuthStateEvent()

    class GetOrganisationListEvent() :AuthStateEvent()

    class UpdatePasswordEvent(
        val employeeID : String,
        val password : String,
        val orgName : String
    ) : AuthStateEvent()

    class None : AuthStateEvent()
}