package com.example.covidsymptoms.util

class Constants {

    companion object {

        const val AUTH_ACT = "authactivity"
        const val MAIN_ACT = "mainactivity"

        //encryption or decryption purposes
        const val MASTER_KEY = "alias_for_keystore"
        const val KEY_EMPID = "empid key"
        const val KEY_PASSWORD = "password_key"
        const val KEY_ORGNAME = "organisation_key"
        const val KEY_IS_KEYPAIR_GENERATED = "keypair_generated"

        const val RESET_PASSWORD_101 = "Password reset successful!"

        const val IN_FOREGROUND = "app_in_foreground"
        const val IN_BACKGROUND = "app_in_background"

        //Notification Channel
        const val CHANNEL_ID = "channel_main"
        const val CHANNEL_NAME = "SRIDShield Channel"

        const val KEY_LOGOUT = "logging out"

        //SharedPreferences
        const val PREFS_NAME = "SRID_Shield"
        const val KEY_DATE = "date"
        const val KEY_ALARM_SET = "is_alarm_set"
        const val KEY_STATUS = "health_status"

        const val KEY_CURRENT_USER_ORG = "current_user_org"

        //viewTypes coming from server
        const val CHECKBOX_TYPE = 101
        const val EDITBOX_TYPE = 102   //not using right now
        const val SPINNER_TYPE = 103
        const val GROUP_TYPE = 104

        //my own handling
        const val OTHER_TYPE = 105
        const val HEADER_TYPE = 100
        const val SPINNER_PLUS_EDITBOX_TYPE = 106


        //for workManager
        const val KEY_URGENT_ANNOUNCEMENT_EXISTS = "Urgent_announcement_worker_output"

        //color values
        const val COLOR_GREEN = "green"                         //as per server
        const val COLOR_RED = "red"

        //Successful HTTP OK

        const val REG_101_MESSAGE = "Registration successfully done. Kindly sign in to proceed"

        //updation
        const val UPDATION_101 = "Update Successful"

        //navigating to mainAct
        const val HEALTH_STATUS = "healthStatus"
        const val EMP_DETAIL = "empDetail"
        const val LAST_FILLED_TIME = "last_filled"
        const val RESULT_MESSAGE = "result message"
        const val RESULT_MESSAGE_REDLIST = "result message redlist user"


        const val NETWORK_TIMEOUT = 10000L      //10 seconds
        const val TESTING_NETWORK_DELAY = 0L // fake network delay for testing


    }
}