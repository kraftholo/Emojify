package com.example.covidsymptoms.models

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class AuthToken(
    var token : String? = null
) : Parcelable{
    override fun toString(): String {
        return "AuthToken(token=$token)"
    }
}