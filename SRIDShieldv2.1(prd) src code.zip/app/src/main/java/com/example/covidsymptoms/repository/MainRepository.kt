package com.example.covidsymptoms.repository

import android.util.Log
import androidx.lifecycle.LiveData
import com.example.covidsymptoms.BuildConfig
import com.example.covidsymptoms.api.RetrofitBuilder
import com.example.covidsymptoms.api.main.responses.AnnouncementResponse
import com.example.covidsymptoms.api.main.responses.GetQuestionnaireResponse
import com.example.covidsymptoms.models.UpdateQuestionnaireObj
import com.example.covidsymptoms.api.main.responses.UpdationResponse
import com.example.covidsymptoms.models.Question
import com.example.covidsymptoms.ui.DataState
import com.example.covidsymptoms.ui.Response
import com.example.covidsymptoms.ui.ResponseType
import com.example.covidsymptoms.ui.main.state.MainViewState
import com.example.covidsymptoms.ui.main.state.UpdationFields
import com.example.covidsymptoms.util.*
import com.example.covidsymptoms.util.ErrorHandling.Companion.AUTHTOKEN_EXPIRED
import kotlinx.coroutines.Job


object MainRepository {

    private val TAG = "MainRepository"

    private var isStaging = BuildConfig.IS_STAGING

    private var repositoryJob: Job? = null

    private var nwChecker: NetworkChecker? = null

    fun setNetworkChecker(networkChecker: NetworkChecker) {
        nwChecker = networkChecker
    }

    fun clearReferenceToActivity() {
        nwChecker = null
    }


    //TODO()- Use time as required by the server
    fun updateServerDb(
        token: String,
        orgName: String,
        date: String,
        time: String,
        healthStatus: String,
        questionsList: List<Question>
    ): LiveData<DataState<MainViewState>> {
        var org = orgName

        return object :
            NetworkBoundResource<UpdationResponse, MainViewState>(nwChecker!!.isConnectedToTheInternet()) {
            override fun createCall(): LiveData<GenericApiResponse<UpdationResponse>> {
                if(isStaging) org = org+"-STG"
                return RetrofitBuilder.mainApiService.updateQuestionnaireDb(
                    token,
                    org,
                    date,
                    UpdateQuestionnaireObj(
                        healthStatus = healthStatus,
                        questions = questionsList,
                        time = time
                    )
                )
            }

            override suspend fun handleApiSuccessResponse(response: ApiSuccessResponse<UpdationResponse>) {
                Log.d("MainRepository", "handleApiSuccessResponse - response = $response")

                when (response.body.code) {
                    101 -> {
                        onCompleteJob(
                            DataState.data(
                                data = MainViewState(
                                    updationFields = UpdationFields(null,response.body.healthStatus) ,
                                    resultMessage = response.body.message,
                                    resultMessageRedList = response.body.messageRedListUser
                                ),
                                response = Response(response.body.description, ResponseType.None())
                            )
                        )
                    }

                    107 -> {
                        onErrorReturn(ErrorHandling.INTERNAL_SERVER_ERROR_MESSAGE, true, false)
                    }

                    108 -> {
                        onCompleteJob(
                            DataState.data(
                                null,
                                Response(AUTHTOKEN_EXPIRED, ResponseType.None())
                            )
                        )
                    }
                    else -> {
                        onErrorReturn(response.body.description, true, false)
                    }
                }
            }

            override fun setJob(job: Job) {
                Log.d("MainRepository", "setJob - $job")
                repositoryJob?.cancel()
                repositoryJob = job
            }

        }.asLiveData()
    }

    fun getQuestionnaireFromServer(
        token: String,
        orgName: String,
        date: String,
        isFirstRequest: Boolean
    ): LiveData<DataState<MainViewState>> {
        var org = orgName
        if(isStaging) org = org+"-STG"

        Log.e("MainRepository","orgname - $org")

        return object :
            NetworkBoundResource<GetQuestionnaireResponse, MainViewState>(
                nwChecker!!.isConnectedToTheInternet(),
                isFirstRequest
            ) {
            override fun createCall(): LiveData<GenericApiResponse<GetQuestionnaireResponse>> {
                return RetrofitBuilder.mainApiService.getQuestionnaireFromServer(
                    token,
                    org,
                    date
                )
            }

            override suspend fun handleApiSuccessResponse(response: ApiSuccessResponse<GetQuestionnaireResponse>) {
                Log.d("MainRepository", "handleApiSuccessResponse - response.body = ${response.body} , response.body.code = ${response.body.code}")
                when (response.body.code) {
                    101 -> {
                        Log.d("MainRepository", "handleApiSuccessResponse - response.body.questions = ${response.body.questions} , response.body.healthStatus = ${response.body.healthStatus}")
                        val questions = response.body.questions
                        var flag = true
                        questions?.let {
                            for (ques in it){
                                if(ques.viewType == 104){
                                    if(ques.children.size != 6){
                                        flag = false
                                        break
                                    }
                                }
                            }
                        }

                        if(!flag){
                            Log.e("MainRepository","handleApiSuccessResponse() - response was 101 but 104 type children no not matching ")
                            onErrorReturn(
                                ErrorHandling.QUESTIONNAIRE_INTERNAL_SERVER_ERROR,
                                false,
                                false
                            )
                            return
                        }else{
                            onCompleteJob(
                                DataState.data(
                                    data = MainViewState(
                                        UpdationFields(
                                            response.body.questions,
                                            null
                                        )
                                    ),
                                    response = null
                                )
                            )
                        }


                    }
                    102 -> {
                        onErrorReturn(ErrorHandling.QUESTIONNAIRE_NOT_AVAILABLE, false, false)
                    }

                    107 -> {
                        onErrorReturn(
                            ErrorHandling.QUESTIONNAIRE_INTERNAL_SERVER_ERROR,
                            false,
                            false
                        )
                    }

                    108 -> {
                        onCompleteJob(
                            DataState.data(
                                null,
                                Response(AUTHTOKEN_EXPIRED, ResponseType.None())
                            )
                        )
                    }
                    else -> {
                        onErrorReturn(response.body.description, true, false)
                    }

                }
            }

            override fun setJob(job: Job) {
                repositoryJob?.cancel()
                repositoryJob = job
            }

        }.asLiveData()
    }

    fun getAnnouncementFromServer(
        token: String,
        orgName: String,
        date: String,
        isFirstRequest: Boolean
    ): LiveData<DataState<MainViewState>> {
        var org = orgName
        if(isStaging) org = org+"-STG"

        return object :
            NetworkBoundResource<AnnouncementResponse, MainViewState>(nwChecker!!.isConnectedToTheInternet(),isFirstRequest) {
            override fun createCall(): LiveData<GenericApiResponse<AnnouncementResponse>> {
                return RetrofitBuilder.mainApiService.getAnnouncement(
                    token,
                    org,
                    date
                )
            }

            override suspend fun handleApiSuccessResponse(response: ApiSuccessResponse<AnnouncementResponse>) {
                Log.d("MainRepository", "handleApiSuccessResponse - response = $response")
                when (response.body.code) {
                    101 -> {
                        onCompleteJob(
                            DataState.data(
                                MainViewState(null, response.body.announcement)
                            )
                        )
                    }

                    //User doesnt need to know, just proceed as if no announcement for today
                    107 -> {
                        onErrorReturn(ErrorHandling.INTERNAL_SERVER_ERROR_MESSAGE, true, false)
                    }


                    108 -> {
                        onCompleteJob(
                            DataState.data(
                                null,
                                Response(AUTHTOKEN_EXPIRED, ResponseType.None())
                            )
                        )
                    }
                    else -> {
                        //User doesnt need to know, just proceed as if no announcement for today
                        Log.e("MainRepository", "UNSUCCESSFUL getAnnouncement endpoint response!!")
                        onCompleteJob(
                            DataState.data(
                                MainViewState(null, "")
                                ,
                                Response(response.body.description, ResponseType.None())
                            )
                        )
                    }
                }
            }

            override fun setJob(job: Job) {
                repositoryJob?.cancel()
                repositoryJob = job
            }

        }.asLiveData()

    }

    private fun returnErrorResponse(
        errorMessage: String,
        responseType: ResponseType
    ): LiveData<DataState<MainViewState>> {
        Log.e(TAG, "returnErrorResponse: ${errorMessage}")

        return object : LiveData<DataState<MainViewState>>() {
            override fun onActive() {
                super.onActive()
                value = DataState.error(
                    Response(
                        errorMessage,
                        responseType
                    )
                )
            }
        }
    }

    fun cancelActiveJobs() {
        Log.d(TAG, "MainRepository: Cancelling on-going jobs...")
        repositoryJob?.cancel()
    }

}