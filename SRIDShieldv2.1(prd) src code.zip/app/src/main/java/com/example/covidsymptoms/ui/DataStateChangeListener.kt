package com.example.covidsymptoms.ui

interface DataStateChangeListener{

    fun onDataStateChange(dataState: DataState<*>?)

    fun hideSoftKeyboard()
}