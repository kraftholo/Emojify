package com.example.covidsymptoms.api

import com.example.covidsymptoms.api.main.responses.UrgentAnnouncementResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Header

interface NotificationApiService {

    @GET("asdasd")
    fun getUrgentNotification(
        @Header("orgname") orgName: String
    ): Call<UrgentAnnouncementResponse>
}