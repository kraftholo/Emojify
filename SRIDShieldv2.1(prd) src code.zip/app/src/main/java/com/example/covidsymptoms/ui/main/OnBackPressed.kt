package com.example.covidsymptoms.ui.main

//Used later
interface OnBackPressed{

    fun onBackPressed()
}