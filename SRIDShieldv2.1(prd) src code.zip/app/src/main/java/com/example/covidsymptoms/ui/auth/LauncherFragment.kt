package com.example.covidsymptoms.ui.auth

import android.os.Bundle
import android.util.Log
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.covidsymptoms.R
import kotlinx.android.synthetic.main.fragment_launcher.*
import kotlinx.android.synthetic.main.fragment_launcher.signInButton

class LauncherFragment : Fragment() {

    val TAG = "LauncherFragment"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val viewModel: AuthViewModel by activityViewModels()
        Log.d(TAG, "Viewmodel - ${viewModel.hashCode()}")

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_launcher, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setHasOptionsMenu(true)

        registerButton.setOnClickListener {
            navRegistration()
        }

        signInButton.setOnClickListener {
            navSignIn()
        }

    }

    private fun navSignIn(){
        Log.d(TAG, "navSignIn() - Opening SignInFragment")
        findNavController().navigate(R.id.action_launcherFragment_to_signInFragment)
    }

    private fun navRegistration() {
        Log.d(TAG, "navRegistration() - Opening RegisterFragment")
        findNavController().navigate(R.id.action_launcherFragment_to_registerFragment)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.launcher_menu, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_help -> {
                Log.d(TAG, "Opening HelpFragment")
                findNavController().navigate(R.id.action_launcherFragment_to_helpFragment)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}
