package com.example.covidsymptoms.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.work.OneTimeWorkRequest
import androidx.work.WorkManager
import com.example.covidsymptoms.worker.AlarmNotificationWorker

//called every 2 hours after 8am alarm if questionnaire not filled
class NextAlarmReceiver: BroadcastReceiver() {
    lateinit var workManager: WorkManager

    override fun onReceive(context: Context, intent: Intent) {
       // Toast.makeText(context, "onReceive() of NextAlarmReceiver was triggered! Starting WorkManager", Toast.LENGTH_LONG).show()

        workManager = WorkManager.getInstance(context)
        val workRequest = OneTimeWorkRequest.Builder(AlarmNotificationWorker::class.java)
            .build()
        workManager.enqueue(workRequest)

    }

}